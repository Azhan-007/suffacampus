import {
  HTMLRewriter,
  __require
} from "./chunk-ECGXHPZS.js";

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/matchers.json
var matchers_default = [{ regexp: "^(?:\\/(_next\\/data\\/[^/]{1,}))?(?:\\/((?!_next\\/static|_next\\/image|favicon.ico).*))(.json)?[\\/#\\?]?$", originalSource: "/((?!_next/static|_next/image|favicon.ico).*)" }];

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/next.config.json
var next_config_default = { basePath: "", i18n: null, trailingSlash: false };

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/headers.ts
var InternalHeaders = {
  NFDebugLogging: "x-nf-debug-logging",
  NFRequestID: "x-nf-request-id"
};
function updateModifiedHeaders(requestHeaders, responseHeaders) {
  const overriddenHeaders = responseHeaders.get("x-middleware-override-headers");
  if (!overriddenHeaders) {
    return;
  }
  const headersToUpdate = new Set(overriddenHeaders.split(",").map((header) => header.trim()));
  for (const key of [
    ...requestHeaders.keys()
  ]) {
    if (!headersToUpdate.has(key)) {
      requestHeaders.delete(key);
    }
  }
  for (const header of headersToUpdate) {
    const oldHeaderKey = "x-middleware-request-" + header;
    const headerValue = responseHeaders.get(oldHeaderKey) || "";
    const oldValue = requestHeaders.get(header) || "";
    if (oldValue !== headerValue) {
      if (headerValue) {
        requestHeaders.set(header, headerValue);
      } else {
        requestHeaders.delete(header);
      }
    }
    responseHeaders.delete(oldHeaderKey);
  }
  responseHeaders.delete("x-middleware-override-headers");
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/vendor/v1-7-0--edge-utils.netlify.app/logger/logger.ts
var LogLevel = /* @__PURE__ */ function(LogLevel2) {
  LogLevel2[LogLevel2["Debug"] = 1] = "Debug";
  LogLevel2[LogLevel2["Log"] = 2] = "Log";
  LogLevel2[LogLevel2["Error"] = 3] = "Error";
  return LogLevel2;
}({});
var serializeError = (error) => {
  const cause = error?.cause instanceof Error ? serializeError(error.cause) : error.cause;
  return {
    error: error.message,
    error_cause: cause,
    error_stack: error.stack
  };
};
var StructuredLogger = class _StructuredLogger {
  fields;
  logLevel;
  message;
  rawLogger;
  requestID;
  __netlifyStructuredLogger;
  constructor(message, fields, requestID, rawLogger, logLevel) {
    this.fields = fields ?? {};
    this.logLevel = logLevel ?? LogLevel.Log;
    this.message = message ?? "";
    this.rawLogger = rawLogger;
    this.requestID = requestID;
    this.__netlifyStructuredLogger = 1;
  }
  debug(message) {
    if (this.logLevel > LogLevel.Debug) {
      return;
    }
    const logger2 = this.rawLogger ?? globalThis.console.log;
    logger2(new _StructuredLogger(message, this.fields, this.requestID, this.rawLogger, this.logLevel));
  }
  error(message) {
    if (this.logLevel > LogLevel.Error) {
      return;
    }
    const logger2 = this.rawLogger ?? globalThis.console.log;
    logger2(new _StructuredLogger(message, this.fields, this.requestID, this.rawLogger, this.logLevel));
  }
  log(message) {
    if (this.logLevel > LogLevel.Log) {
      return;
    }
    const logger2 = this.rawLogger ?? globalThis.console.log;
    logger2(new _StructuredLogger(message, this.fields, this.requestID, this.rawLogger, this.logLevel));
  }
  serialize() {
    const log = {
      fields: this.fields,
      message: this.message,
      requestID: this.requestID
    };
    return log;
  }
  withError(error) {
    const fields = error instanceof Error ? serializeError(error) : {
      error
    };
    return this.withFields(fields);
  }
  withFields(fields) {
    return new _StructuredLogger(this.message, {
      ...this.fields,
      ...fields
    }, this.requestID, this.rawLogger, this.logLevel);
  }
  withLogLevel(logLevel) {
    return new _StructuredLogger(this.message, this.fields, this.requestID, this.rawLogger, logLevel);
  }
  withRawLogger(logger2) {
    return new _StructuredLogger(this.message, this.fields, this.requestID, logger2, this.logLevel);
  }
  withRequestID(requestID) {
    if (requestID === null) {
      return this;
    }
    return new _StructuredLogger(this.message, this.fields, requestID, this.rawLogger, this.logLevel);
  }
};
var logger = new StructuredLogger();

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/util.ts
function normalizeDataUrl(urlPath) {
  if (urlPath.startsWith("/_next/data/") && urlPath.includes(".json")) {
    const paths = urlPath.replace(/^\/_next\/data\//, "").replace(/\.json/, "").split("/");
    urlPath = paths[1] !== "index" ? `/${paths.slice(1).join("/")}` : "/";
  }
  return urlPath;
}
var removeBasePath = (path, basePath) => {
  if (basePath && path.startsWith(basePath)) {
    return path.replace(basePath, "");
  }
  return path;
};
var addBasePath = (path, basePath) => {
  if (basePath && !path.startsWith(basePath)) {
    return `${basePath}${path}`;
  }
  return path;
};
var addLocale = (path, locale) => {
  if (locale && path.toLowerCase() !== `/${locale.toLowerCase()}` && !path.toLowerCase().startsWith(`/${locale.toLowerCase()}/`) && !path.startsWith(`/api/`) && !path.startsWith(`/_next/`)) {
    return `/${locale}${path}`;
  }
  return path;
};
function normalizeLocalePath(pathname, locales) {
  let detectedLocale;
  const pathnameParts = pathname.split("/");
  (locales || []).some((locale) => {
    if (pathnameParts[1] && pathnameParts[1].toLowerCase() === locale.toLowerCase()) {
      detectedLocale = locale;
      pathnameParts.splice(1, 1);
      pathname = pathnameParts.join("/");
      return true;
    }
    return false;
  });
  return {
    pathname,
    detectedLocale
  };
}
function relativizeURL(url, base) {
  const baseURL = typeof base === "string" ? new URL(base) : base;
  const relative = new URL(url, base);
  const origin = `${baseURL.protocol}//${baseURL.host}`;
  return `${relative.protocol}//${relative.host}` === origin ? relative.toString().replace(origin, "") : relative.toString();
}
var normalizeIndex = (path) => path === "/" ? "/index" : path;
var normalizeTrailingSlash = (path, trailingSlash) => trailingSlash ? addTrailingSlash(path) : stripTrailingSlash(path);
var stripTrailingSlash = (path) => path !== "/" && path.endsWith("/") ? path.slice(0, -1) : path;
var addTrailingSlash = (path) => path.endsWith("/") ? path : `${path}/`;
function rewriteDataPath({ dataUrl, newRoute, basePath }) {
  const normalizedDataUrl = normalizeDataUrl(removeBasePath(dataUrl, basePath));
  return addBasePath(dataUrl.replace(normalizeIndex(normalizedDataUrl), stripTrailingSlash(normalizeIndex(newRoute))), basePath);
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/next-request.ts
var normalizeRequestURL = (originalURL, nextConfig) => {
  const url = new URL(originalURL);
  let pathname = removeBasePath(url.pathname, nextConfig?.basePath);
  const { detectedLocale } = normalizeLocalePath(pathname, nextConfig?.i18n?.locales);
  if (!nextConfig?.skipMiddlewareUrlNormalize) {
    pathname = normalizeDataUrl(pathname);
    if (nextConfig?.trailingSlash) {
      pathname = addTrailingSlash(pathname);
    }
  }
  url.pathname = addBasePath(pathname, nextConfig?.basePath);
  return {
    url: url.toString(),
    detectedLocale
  };
};
var localizeRequest = (url, nextConfig) => {
  const localizedUrl = new URL(url);
  localizedUrl.pathname = removeBasePath(localizedUrl.pathname, nextConfig?.basePath);
  const { detectedLocale } = normalizeLocalePath(localizedUrl.pathname, nextConfig?.i18n?.locales);
  localizedUrl.pathname = addLocale(localizedUrl.pathname, detectedLocale ?? nextConfig?.i18n?.defaultLocale);
  localizedUrl.pathname = addBasePath(localizedUrl.pathname, nextConfig?.basePath);
  return {
    localizedUrl,
    locale: detectedLocale
  };
};
var buildNextRequest = (request, context, nextConfig) => {
  const { url, method, body, headers } = request;
  const { country, subdivision, city, latitude, longitude, timezone } = context.geo;
  const geo = {
    city,
    country: country?.code,
    region: subdivision?.code,
    latitude: latitude?.toString(),
    longitude: longitude?.toString(),
    timezone
  };
  const { detectedLocale, url: normalizedUrl } = normalizeRequestURL(url, nextConfig);
  return {
    headers: Object.fromEntries(headers.entries()),
    geo,
    url: normalizedUrl,
    method,
    ip: context.ip,
    body: body ?? void 0,
    nextConfig,
    detectedLocale
  };
};

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/vendor/deno.land/std@0.175.0/_util/asserts.ts
var DenoStdInternalError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "DenoStdInternalError";
  }
};
function assert(expr, msg = "") {
  if (!expr) {
    throw new DenoStdInternalError(msg);
  }
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/vendor/deno.land/std@0.175.0/http/cookie.ts
function getCookies(headers) {
  const cookie = headers.get("Cookie");
  if (cookie != null) {
    const out = {};
    const c = cookie.split(";");
    for (const kv of c) {
      const [cookieKey, ...cookieVal] = kv.split("=");
      assert(cookieKey != null);
      const key = cookieKey.trim();
      out[key] = cookieVal.join("=");
    }
    return out;
  }
  return {};
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/middleware.ts
function isMiddlewareRequest(response) {
  return "originalRequest" in response;
}
function isMiddlewareResponse(response) {
  return "dataTransforms" in response;
}
var addMiddlewareHeaders = async (originResponse, middlewareResponse) => {
  if ([
    ...middlewareResponse.headers.keys()
  ].length === 0) {
    return originResponse;
  }
  const res = await originResponse;
  const response = new Response(res.body, res);
  middlewareResponse.headers.forEach((value, key) => {
    if (key === "set-cookie") {
      response.headers.append(key, value);
    } else {
      response.headers.set(key, value);
    }
  });
  return response;
};
function mergeMiddlewareCookies(middlewareResponse, lambdaRequest) {
  let mergedCookies = getCookies(lambdaRequest.headers);
  const middlewareCookies = middlewareResponse.headers.get("x-middleware-set-cookie");
  if (middlewareCookies) {
    middlewareResponse.headers.delete("x-middleware-set-cookie");
    const regex = new RegExp(/,(?!\s)/);
    middlewareCookies.split(regex).forEach((entry) => {
      const [cookie] = entry.split("; ");
      const [name, value] = cookie.split("=");
      mergedCookies[name] = value;
    });
  }
  return Object.entries(mergedCookies).map((kv) => kv.join("=")).join("; ");
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/response.ts
var buildResponse = async ({ context, logger: logger2, request, result, nextConfig }) => {
  logger2.withFields({
    is_nextresponse_next: result.response.headers.has("x-middleware-next")
  }).debug("Building Next.js response");
  updateModifiedHeaders(request.headers, result.response.headers);
  if (isMiddlewareRequest(result.response)) {
    result.response = await result.response.next();
  }
  if (isMiddlewareResponse(result.response)) {
    const { response } = result;
    if (request.method === "HEAD" || request.method === "OPTIONS") {
      return response.originResponse;
    }
    if (response.cookies._headers?.has("set-cookie")) {
      response.originResponse.headers.set("set-cookie", response.cookies._headers.get("set-cookie"));
    }
    if (response.originResponse.headers.get("content-type")?.includes("application/json")) {
      const props = await response.originResponse.json();
      const transformed = response.dataTransforms.reduce((prev, transform) => {
        return transform(prev);
      }, props);
      const body = JSON.stringify(transformed);
      const headers = new Headers(response.headers);
      headers.set("content-length", String(body.length));
      return Response.json(transformed, {
        ...response,
        headers
      });
    }
    if (response.dataTransforms.length > 0 || response.elementHandlers.length > 0) {
      if (Deno.env.get("NETLIFY_LOG_HTML_REWRITER") === "true") {
        logger2.withFields({
          dataTransforms_count: response.dataTransforms.length,
          elementHandlers_count: response.elementHandlers.length
        }).log("Using HTMLRewriter for response transformation");
      }
      const { initHtmlRewriter } = await import("./html-rewriter-wasm-EHPDOK7I.js");
      await initHtmlRewriter();
      let buffer = "";
      const rewriter = new HTMLRewriter();
      if (response.dataTransforms.length > 0) {
        rewriter.on('script[id="__NEXT_DATA__"]', {
          text(textChunk) {
            buffer += textChunk.text;
            if (textChunk.lastInTextNode) {
              try {
                const data = JSON.parse(buffer.trim());
                const props = response.dataTransforms.reduce((prev, transform) => transform(prev), data.props);
                textChunk.replace(JSON.stringify({
                  ...data,
                  props
                }), {
                  html: true
                });
              } catch (err) {
                console.log("Could not parse", err);
              }
            } else {
              textChunk.remove();
            }
          }
        });
      }
      if (response.elementHandlers.length > 0) {
        response.elementHandlers.forEach(([selector, handlers]) => rewriter.on(selector, handlers));
      }
      return rewriter.transform(response.originResponse);
    } else {
      return response.originResponse;
    }
  }
  const edgeResponse = new Response(result.response.body, result.response);
  request.headers.set("x-nf-next-middleware", "skip");
  let rewrite = edgeResponse.headers.get("x-middleware-rewrite");
  let redirect = edgeResponse.headers.get("location");
  let nextRedirect = edgeResponse.headers.get("x-nextjs-redirect");
  const isDataReq = request.headers.has("x-nextjs-data");
  if (isDataReq && !redirect && !rewrite && !nextRedirect) {
    const requestUrl = new URL(request.url);
    const normalizedDataUrl = normalizeDataUrl(requestUrl.pathname);
    if (normalizedDataUrl !== requestUrl.pathname) {
      rewrite = `${normalizedDataUrl}${requestUrl.search}`;
      logger2.withFields({
        rewrite_url: rewrite
      }).debug("Rewritten data URL");
    }
  }
  if (rewrite) {
    logger2.withFields({
      rewrite_url: rewrite
    }).debug("Found middleware rewrite");
    const rewriteUrl = new URL(rewrite, request.url);
    const baseUrl = new URL(request.url);
    if (rewriteUrl.toString() === baseUrl.toString()) {
      logger2.withFields({
        rewrite_url: rewrite
      }).debug("Rewrite url is same as original url");
      return;
    }
    const relativeUrl = relativizeURL(rewrite, request.url);
    if (isDataReq) {
      edgeResponse.headers.set("x-nextjs-rewrite", relativeUrl);
    }
    if (rewriteUrl.origin !== baseUrl.origin) {
      logger2.withFields({
        rewrite_url: rewrite
      }).debug("Rewriting to external url");
      const proxyRequest = await cloneRequest(rewriteUrl, request);
      for (const key of request.headers.keys()) {
        if (key.startsWith("x-nf-")) {
          proxyRequest.headers.delete(key);
        }
      }
      return addMiddlewareHeaders(fetch(proxyRequest, {
        redirect: "manual"
      }), edgeResponse);
    }
    if (isDataReq) {
      rewriteUrl.pathname = rewriteDataPath({
        dataUrl: new URL(request.url).pathname,
        newRoute: removeBasePath(rewriteUrl.pathname, nextConfig?.basePath),
        basePath: nextConfig?.basePath
      });
    } else {
      rewriteUrl.pathname = normalizeTrailingSlash(rewriteUrl.pathname, nextConfig?.trailingSlash);
    }
    const target = normalizeLocalizedTarget({
      target: rewriteUrl.toString(),
      request,
      nextConfig
    });
    if (target === request.url) {
      logger2.withFields({
        rewrite_url: rewrite
      }).debug("Rewrite url is same as original url");
      return;
    }
    edgeResponse.headers.set("x-middleware-rewrite", relativeUrl);
    request.headers.set("x-middleware-rewrite", target);
    const newRequest = await cloneRequest(target, request);
    const newRequestCookies = mergeMiddlewareCookies(edgeResponse, newRequest);
    if (newRequestCookies) {
      newRequest.headers.set("Cookie", newRequestCookies);
    }
    return addMiddlewareHeaders(context.next(newRequest), edgeResponse);
  }
  if (redirect) {
    redirect = normalizeLocalizedTarget({
      target: redirect,
      request,
      nextConfig
    });
    if (redirect === request.url) {
      logger2.withFields({
        redirect_url: redirect
      }).debug("Redirect url is same as original url");
      return;
    }
    edgeResponse.headers.set("location", relativizeURL(redirect, request.url));
  }
  if (redirect && isDataReq) {
    edgeResponse.headers.delete("location");
    edgeResponse.headers.set("x-nextjs-redirect", relativizeURL(redirect, request.url));
  }
  nextRedirect = edgeResponse.headers.get("x-nextjs-redirect");
  if (nextRedirect && isDataReq) {
    edgeResponse.headers.set("x-nextjs-redirect", normalizeDataUrl(nextRedirect));
  }
  if (edgeResponse.headers.get("x-middleware-next") === "1") {
    edgeResponse.headers.delete("x-middleware-next");
    const newRequest = await cloneRequest(request.url, request);
    const newRequestCookies = mergeMiddlewareCookies(edgeResponse, newRequest);
    if (newRequestCookies) {
      newRequest.headers.set("Cookie", newRequestCookies);
    }
    return addMiddlewareHeaders(context.next(newRequest), edgeResponse);
  }
  return edgeResponse;
};
function normalizeLocalizedTarget({ target, request, nextConfig }) {
  const targetUrl = new URL(target, request.url);
  const normalizedTarget = normalizeLocalePath(targetUrl.pathname, nextConfig?.i18n?.locales);
  if (normalizedTarget.detectedLocale && !normalizedTarget.pathname.startsWith(`/api/`) && !normalizedTarget.pathname.startsWith(`/_next/static/`)) {
    targetUrl.pathname = addBasePath(`/${normalizedTarget.detectedLocale}${normalizedTarget.pathname}`, nextConfig?.basePath) || `/`;
  } else {
    targetUrl.pathname = addBasePath(normalizedTarget.pathname, nextConfig?.basePath) || `/`;
  }
  return targetUrl.toString();
}
async function cloneRequest(url, request) {
  const body = request.body && !request.bodyUsed ? await request.arrayBuffer() : void 0;
  return new Request(url, {
    headers: request.headers,
    method: request.method,
    body
  });
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/lib/routing.ts
function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === "undefined") {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [
        query[key],
        value
      ];
    }
  });
  return query;
}
function matchHas(req, query, has = [], missing = []) {
  const params = {};
  const cookies = getCookies(req.headers);
  const url = new URL(req.url);
  const hasMatch = (hasItem) => {
    let value;
    let key = hasItem.key;
    switch (hasItem.type) {
      case "header": {
        key = hasItem.key.toLowerCase();
        value = req.headers.get(key);
        break;
      }
      case "cookie": {
        value = cookies[hasItem.key];
        break;
      }
      case "query": {
        value = query[hasItem.key];
        break;
      }
      case "host": {
        value = url.hostname;
        break;
      }
      default: {
        break;
      }
    }
    if (!hasItem.value && value && key) {
      params[getSafeParamName(key)] = value;
      return true;
    } else if (value) {
      const matcher = new RegExp(`^${hasItem.value}$`);
      const matches = Array.isArray(value) ? value.slice(-1)[0].match(matcher) : value.match(matcher);
      if (matches) {
        if (Array.isArray(matches)) {
          if (matches.groups) {
            Object.keys(matches.groups).forEach((groupKey) => {
              params[groupKey] = matches.groups[groupKey];
            });
          } else if (hasItem.type === "host" && matches[0]) {
            params.host = matches[0];
          }
        }
        return true;
      }
    }
    return false;
  };
  const allMatch = has.every((item) => hasMatch(item)) && !missing.some((item) => hasMatch(item));
  if (allMatch) {
    return params;
  }
  return false;
}
function getSafeParamName(paramName) {
  let newParamName = "";
  for (let i = 0; i < paramName.length; i++) {
    const charCode = paramName.charCodeAt(i);
    if (charCode > 64 && charCode < 91 || // A-Z
    charCode > 96 && charCode < 123) {
      newParamName += paramName[i];
    }
  }
  return newParamName;
}
var decodeMaybeEncodedPath = (path) => {
  try {
    return decodeURIComponent(path);
  } catch {
    return path;
  }
};
function getMiddlewareRouteMatcher(matchers) {
  return (unsafePathname, req, query) => {
    const pathname = decodeMaybeEncodedPath(unsafePathname ?? "");
    for (const matcher of matchers) {
      const routeMatch = new RegExp(matcher.regexp).exec(pathname);
      if (!routeMatch) {
        continue;
      }
      if (matcher.has || matcher.missing) {
        const hasParams = matchHas(req, query, matcher.has, matcher.missing);
        if (!hasParams) {
          continue;
        }
      }
      return true;
    }
    return false;
  };
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/edge-runtime/middleware.ts
var matchesMiddleware = getMiddlewareRouteMatcher(matchers_default || []);
async function handleMiddleware(request, context, nextHandler) {
  const url = new URL(request.url);
  const reqLogger = logger.withLogLevel(request.headers.has(InternalHeaders.NFDebugLogging) ? LogLevel.Debug : LogLevel.Log).withFields({
    url_path: url.pathname
  }).withRequestID(request.headers.get(InternalHeaders.NFRequestID));
  const { localizedUrl } = localizeRequest(url, next_config_default);
  if (!matchesMiddleware(localizedUrl.pathname, request, searchParamsToUrlQuery(url.searchParams))) {
    reqLogger.debug("Aborting middleware due to runtime rules");
    return;
  }
  const nextRequest = buildNextRequest(request, context, next_config_default);
  try {
    const result = await nextHandler({
      request: nextRequest
    });
    const response = await buildResponse({
      context,
      logger: reqLogger,
      request,
      result,
      nextConfig: next_config_default
    });
    return response;
  } catch (error) {
    console.error(error);
    return new Response(error.message, {
      status: 500
    });
  }
}

// .netlify/edge-functions/___netlify-edge-handler-middleware/server/middleware.js
import { AsyncLocalStorage } from "node:async_hooks";
import process from "node:process";
import * as BufferCompat from "node:buffer";
import * as EventsCompat from "node:events";
import * as AsyncHooksCompat from "node:async_hooks";
import * as AssertCompat from "node:assert";
import * as UtilCompat from "node:util";
globalThis.process = process;
globalThis.AsyncLocalStorage = AsyncLocalStorage;
globalThis.require = function nextRuntimeMinimalRequireShim(name) {
  switch (name.replace(/^node:/, "")) {
    case "buffer":
      return BufferCompat;
    case "events":
      return EventsCompat;
    case "async_hooks":
      return AsyncHooksCompat;
    case "assert":
      return AssertCompat;
    case "util":
      return UtilCompat;
    default:
      throw new ReferenceError(`require is not defined`);
  }
};
var _ENTRIES = {};
try {
  self._ENTRIES = _ENTRIES;
} catch {
}
self.__PRERENDER_MANIFEST = '{"version":4,"routes":{"/forgot-password":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/forgot-password","dataRoute":"/forgot-password.rsc"},"/notifications":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/notifications","dataRoute":"/notifications.rsc"},"/":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/","dataRoute":"/index.rsc"},"/parent":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/parent","dataRoute":"/parent.rsc"},"/parent/link":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/parent/link","dataRoute":"/parent/link.rsc"},"/admin/schools":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/admin/schools","dataRoute":"/admin/schools.rsc"},"/pricing":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/pricing","dataRoute":"/pricing.rsc"},"/login":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/login","dataRoute":"/login.rsc"},"/settings/audit-logs":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/settings/audit-logs","dataRoute":"/settings/audit-logs.rsc"},"/dashboard":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/dashboard","dataRoute":"/dashboard.rsc"},"/results":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/results","dataRoute":"/results.rsc"},"/settings":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/settings","dataRoute":"/settings.rsc"},"/settings/branding":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/settings/branding","dataRoute":"/settings/branding.rsc"},"/settings/parent-invites":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/settings/parent-invites","dataRoute":"/settings/parent-invites.rsc"},"/settings/permissions":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/settings/permissions","dataRoute":"/settings/permissions.rsc"},"/settings/sessions":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/settings/sessions","dataRoute":"/settings/sessions.rsc"},"/settings/privacy":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/settings/privacy","dataRoute":"/settings/privacy.rsc"},"/reports":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/reports","dataRoute":"/reports.rsc"},"/settings/subscription":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/settings/subscription","dataRoute":"/settings/subscription.rsc"},"/superadmin/audit-logs":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/superadmin/audit-logs","dataRoute":"/superadmin/audit-logs.rsc"},"/settings/webhooks":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/settings/webhooks","dataRoute":"/settings/webhooks.rsc"},"/settings/api":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/settings/api","dataRoute":"/settings/api.rsc"},"/superadmin":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/superadmin","dataRoute":"/superadmin.rsc"},"/superadmin/schools":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/superadmin/schools","dataRoute":"/superadmin/schools.rsc"},"/test-bare":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/test-bare","dataRoute":"/test-bare.rsc"},"/test-login":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/test-login","dataRoute":"/test-login.rsc"},"/library":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/library","dataRoute":"/library.rsc"},"/classes":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/classes","dataRoute":"/classes.rsc"},"/students":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/students","dataRoute":"/students.rsc"},"/fees":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/fees","dataRoute":"/fees.rsc"},"/attendance":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/attendance","dataRoute":"/attendance.rsc"},"/events":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/events","dataRoute":"/events.rsc"},"/teachers":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/teachers","dataRoute":"/teachers.rsc"},"/timetable":{"experimentalBypassFor":[{"type":"header","key":"Next-Action"},{"type":"header","key":"content-type","value":"multipart/form-data;.*"}],"initialRevalidateSeconds":false,"srcRoute":"/timetable","dataRoute":"/timetable.rsc"}},"dynamicRoutes":{},"notFoundRoutes":[],"preview":{"previewModeId":"process.env.__NEXT_PREVIEW_MODE_ID","previewModeSigningKey":"process.env.__NEXT_PREVIEW_MODE_SIGNING_KEY","previewModeEncryptionKey":"process.env.__NEXT_PREVIEW_MODE_ENCRYPTION_KEY"}}';
(() => {
  "use strict";
  var e = {}, r = {};
  function t(o) {
    var n = r[o];
    if (void 0 !== n) return n.exports;
    var i = r[o] = {
      exports: {}
    }, l = true;
    try {
      e[o](i, i.exports, t), l = false;
    } finally {
      l && delete r[o];
    }
    return i.exports;
  }
  t.m = e, t.amdO = {}, (() => {
    var e2 = [];
    t.O = (r2, o, n, i) => {
      if (o) {
        i = i || 0;
        for (var l = e2.length; l > 0 && e2[l - 1][2] > i; l--) e2[l] = e2[l - 1];
        e2[l] = [
          o,
          n,
          i
        ];
        return;
      }
      for (var a = 1 / 0, l = 0; l < e2.length; l++) {
        for (var [o, n, i] = e2[l], f = true, u = 0; u < o.length; u++) a >= i && Object.keys(t.O).every((e3) => t.O[e3](o[u])) ? o.splice(u--, 1) : (f = false, i < a && (a = i));
        if (f) {
          e2.splice(l--, 1);
          var s = n();
          void 0 !== s && (r2 = s);
        }
      }
      return r2;
    };
  })(), t.d = (e2, r2) => {
    for (var o in r2) t.o(r2, o) && !t.o(e2, o) && Object.defineProperty(e2, o, {
      enumerable: true,
      get: r2[o]
    });
  }, t.g = function() {
    if ("object" == typeof globalThis) return globalThis;
    try {
      return this || Function("return this")();
    } catch (e2) {
      if ("object" == typeof window) return window;
    }
  }(), t.o = (e2, r2) => Object.prototype.hasOwnProperty.call(e2, r2), t.r = (e2) => {
    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, {
      value: "Module"
    }), Object.defineProperty(e2, "__esModule", {
      value: true
    });
  }, (() => {
    var e2 = {
      993: 0
    };
    t.O.j = (r3) => 0 === e2[r3];
    var r2 = (r3, o2) => {
      var n, i, [l, a, f] = o2, u = 0;
      if (l.some((r4) => 0 !== e2[r4])) {
        for (n in a) t.o(a, n) && (t.m[n] = a[n]);
        if (f) var s = f(t);
      }
      for (r3 && r3(o2); u < l.length; u++) i = l[u], t.o(e2, i) && e2[i] && e2[i][0](), e2[i] = 0;
      return t.O(s);
    }, o = self.webpackChunk_N_E = self.webpackChunk_N_E || [];
    o.forEach(r2.bind(null, 0)), o.push = r2.bind(null, o.push.bind(o));
  })();
})();
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [
    826
  ],
  {
    67: (e) => {
      "use strict";
      e.exports = __require("node:async_hooks");
    },
    195: (e) => {
      "use strict";
      e.exports = __require("node:buffer");
    },
    656: (e, t, r) => {
      "use strict";
      let n;
      r.r(t), r.d(t, {
        default: () => eH
      });
      var i, a, o, s, l, u, d, c, p, g, h, f, b = {};
      async function m() {
        let e2 = "_ENTRIES" in globalThis && _ENTRIES.middleware_instrumentation && (await _ENTRIES.middleware_instrumentation).register;
        if (e2) try {
          await e2();
        } catch (e3) {
          throw e3.message = `An error occurred while loading instrumentation hook: ${e3.message}`, e3;
        }
      }
      r.r(b), r.d(b, {
        config: () => eU,
        middleware: () => eB
      });
      let v = null;
      function w() {
        return v || (v = m()), v;
      }
      function y(e2) {
        return `The edge runtime does not support Node.js '${e2}' module.
Learn More: https://nextjs.org/docs/messages/node-module-in-edge-runtime`;
      }
      process !== r.g.process && (process.env = r.g.process.env, r.g.process = process), Object.defineProperty(globalThis, "__import_unsupported", {
        value: function(e2) {
          let t2 = new Proxy(function() {
          }, {
            get(t3, r2) {
              if ("then" === r2) return {};
              throw Error(y(e2));
            },
            construct() {
              throw Error(y(e2));
            },
            apply(r2, n2, i2) {
              if ("function" == typeof i2[0]) return i2[0](t2);
              throw Error(y(e2));
            }
          });
          return new Proxy({}, {
            get: () => t2
          });
        },
        enumerable: false,
        configurable: false
      }), w();
      class _ extends Error {
        constructor({ page: e2 }) {
          super(`The middleware "${e2}" accepts an async API directly with the form:
  
  export function middleware(request, event) {
    return NextResponse.redirect('/new-location')
  }
  
  Read more: https://nextjs.org/docs/messages/middleware-new-signature
  `);
        }
      }
      class x extends Error {
        constructor() {
          super(`The request.page has been deprecated in favour of \`URLPattern\`.
  Read more: https://nextjs.org/docs/messages/middleware-request-page
  `);
        }
      }
      class S extends Error {
        constructor() {
          super(`The request.ua has been removed in favour of \`userAgent\` function.
  Read more: https://nextjs.org/docs/messages/middleware-parse-user-agent
  `);
        }
      }
      function P(e2) {
        let t2 = {}, r2 = [];
        if (e2) for (let [n2, i2] of e2.entries()) "set-cookie" === n2.toLowerCase() ? (r2.push(...function(e3) {
          var t3, r3, n3, i3, a2, o2 = [], s2 = 0;
          function l2() {
            for (; s2 < e3.length && /\s/.test(e3.charAt(s2)); ) s2 += 1;
            return s2 < e3.length;
          }
          for (; s2 < e3.length; ) {
            for (t3 = s2, a2 = false; l2(); ) if ("," === (r3 = e3.charAt(s2))) {
              for (n3 = s2, s2 += 1, l2(), i3 = s2; s2 < e3.length && "=" !== (r3 = e3.charAt(s2)) && ";" !== r3 && "," !== r3; ) s2 += 1;
              s2 < e3.length && "=" === e3.charAt(s2) ? (a2 = true, s2 = i3, o2.push(e3.substring(t3, n3)), t3 = s2) : s2 = n3 + 1;
            } else s2 += 1;
            (!a2 || s2 >= e3.length) && o2.push(e3.substring(t3, e3.length));
          }
          return o2;
        }(i2)), t2[n2] = 1 === r2.length ? r2[0] : r2) : t2[n2] = i2;
        return t2;
      }
      function O(e2) {
        try {
          return String(new URL(String(e2)));
        } catch (t2) {
          throw Error(`URL is malformed "${String(e2)}". Please use only absolute URLs - https://nextjs.org/docs/messages/middleware-relative-urls`, {
            cause: t2
          });
        }
      }
      let N = Symbol("response"), R = Symbol("passThrough"), T = Symbol("waitUntil");
      class C {
        constructor(e2) {
          this[T] = [], this[R] = false;
        }
        respondWith(e2) {
          this[N] || (this[N] = Promise.resolve(e2));
        }
        passThroughOnException() {
          this[R] = true;
        }
        waitUntil(e2) {
          this[T].push(e2);
        }
      }
      class E extends C {
        constructor(e2) {
          super(e2.request), this.sourcePage = e2.page;
        }
        get request() {
          throw new _({
            page: this.sourcePage
          });
        }
        respondWith() {
          throw new _({
            page: this.sourcePage
          });
        }
      }
      function M(e2) {
        return e2.replace(/\/$/, "") || "/";
      }
      function I(e2) {
        let t2 = e2.indexOf("#"), r2 = e2.indexOf("?"), n2 = r2 > -1 && (t2 < 0 || r2 < t2);
        return n2 || t2 > -1 ? {
          pathname: e2.substring(0, n2 ? r2 : t2),
          query: n2 ? e2.substring(r2, t2 > -1 ? t2 : void 0) : "",
          hash: t2 > -1 ? e2.slice(t2) : ""
        } : {
          pathname: e2,
          query: "",
          hash: ""
        };
      }
      function A(e2, t2) {
        if (!e2.startsWith("/") || !t2) return e2;
        let { pathname: r2, query: n2, hash: i2 } = I(e2);
        return "" + t2 + r2 + n2 + i2;
      }
      function L(e2, t2) {
        if (!e2.startsWith("/") || !t2) return e2;
        let { pathname: r2, query: n2, hash: i2 } = I(e2);
        return "" + r2 + t2 + n2 + i2;
      }
      function k(e2, t2) {
        if ("string" != typeof e2) return false;
        let { pathname: r2 } = I(e2);
        return r2 === t2 || r2.startsWith(t2 + "/");
      }
      function j(e2, t2) {
        let r2;
        let n2 = e2.split("/");
        return (t2 || []).some((t3) => !!n2[1] && n2[1].toLowerCase() === t3.toLowerCase() && (r2 = t3, n2.splice(1, 1), e2 = n2.join("/") || "/", true)), {
          pathname: e2,
          detectedLocale: r2
        };
      }
      let D = /(?!^https?:\/\/)(127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}|\[::1\]|localhost)/;
      function V(e2, t2) {
        return new URL(String(e2).replace(D, "localhost"), t2 && String(t2).replace(D, "localhost"));
      }
      let B = Symbol("NextURLInternal");
      class U {
        constructor(e2, t2, r2) {
          let n2, i2;
          "object" == typeof t2 && "pathname" in t2 || "string" == typeof t2 ? (n2 = t2, i2 = r2 || {}) : i2 = r2 || t2 || {}, this[B] = {
            url: V(e2, n2 ?? i2.base),
            options: i2,
            basePath: ""
          }, this.analyze();
        }
        analyze() {
          var e2, t2, r2, n2, i2;
          let a2 = function(e3, t3) {
            var r3, n3;
            let { basePath: i3, i18n: a3, trailingSlash: o3 } = null != (r3 = t3.nextConfig) ? r3 : {}, s3 = {
              pathname: e3,
              trailingSlash: "/" !== e3 ? e3.endsWith("/") : o3
            };
            i3 && k(s3.pathname, i3) && (s3.pathname = function(e4, t4) {
              if (!k(e4, t4)) return e4;
              let r4 = e4.slice(t4.length);
              return r4.startsWith("/") ? r4 : "/" + r4;
            }(s3.pathname, i3), s3.basePath = i3);
            let l2 = s3.pathname;
            if (s3.pathname.startsWith("/_next/data/") && s3.pathname.endsWith(".json")) {
              let e4 = s3.pathname.replace(/^\/_next\/data\//, "").replace(/\.json$/, "").split("/"), r4 = e4[0];
              s3.buildId = r4, l2 = "index" !== e4[1] ? "/" + e4.slice(1).join("/") : "/", true === t3.parseData && (s3.pathname = l2);
            }
            if (a3) {
              let e4 = t3.i18nProvider ? t3.i18nProvider.analyze(s3.pathname) : j(s3.pathname, a3.locales);
              s3.locale = e4.detectedLocale, s3.pathname = null != (n3 = e4.pathname) ? n3 : s3.pathname, !e4.detectedLocale && s3.buildId && (e4 = t3.i18nProvider ? t3.i18nProvider.analyze(l2) : j(l2, a3.locales)).detectedLocale && (s3.locale = e4.detectedLocale);
            }
            return s3;
          }(this[B].url.pathname, {
            nextConfig: this[B].options.nextConfig,
            parseData: true,
            i18nProvider: this[B].options.i18nProvider
          }), o2 = function(e3, t3) {
            let r3;
            if ((null == t3 ? void 0 : t3.host) && !Array.isArray(t3.host)) r3 = t3.host.toString().split(":", 1)[0];
            else {
              if (!e3.hostname) return;
              r3 = e3.hostname;
            }
            return r3.toLowerCase();
          }(this[B].url, this[B].options.headers);
          this[B].domainLocale = this[B].options.i18nProvider ? this[B].options.i18nProvider.detectDomainLocale(o2) : function(e3, t3, r3) {
            if (e3) for (let a3 of (r3 && (r3 = r3.toLowerCase()), e3)) {
              var n3, i3;
              if (t3 === (null == (n3 = a3.domain) ? void 0 : n3.split(":", 1)[0].toLowerCase()) || r3 === a3.defaultLocale.toLowerCase() || (null == (i3 = a3.locales) ? void 0 : i3.some((e4) => e4.toLowerCase() === r3))) return a3;
            }
          }(null == (t2 = this[B].options.nextConfig) ? void 0 : null == (e2 = t2.i18n) ? void 0 : e2.domains, o2);
          let s2 = (null == (r2 = this[B].domainLocale) ? void 0 : r2.defaultLocale) || (null == (i2 = this[B].options.nextConfig) ? void 0 : null == (n2 = i2.i18n) ? void 0 : n2.defaultLocale);
          this[B].url.pathname = a2.pathname, this[B].defaultLocale = s2, this[B].basePath = a2.basePath ?? "", this[B].buildId = a2.buildId, this[B].locale = a2.locale ?? s2, this[B].trailingSlash = a2.trailingSlash;
        }
        formatPathname() {
          var e2;
          let t2;
          return t2 = function(e3, t3, r2, n2) {
            if (!t3 || t3 === r2) return e3;
            let i2 = e3.toLowerCase();
            return !n2 && (k(i2, "/api") || k(i2, "/" + t3.toLowerCase())) ? e3 : A(e3, "/" + t3);
          }((e2 = {
            basePath: this[B].basePath,
            buildId: this[B].buildId,
            defaultLocale: this[B].options.forceLocale ? void 0 : this[B].defaultLocale,
            locale: this[B].locale,
            pathname: this[B].url.pathname,
            trailingSlash: this[B].trailingSlash
          }).pathname, e2.locale, e2.buildId ? void 0 : e2.defaultLocale, e2.ignorePrefix), (e2.buildId || !e2.trailingSlash) && (t2 = M(t2)), e2.buildId && (t2 = L(A(t2, "/_next/data/" + e2.buildId), "/" === e2.pathname ? "index.json" : ".json")), t2 = A(t2, e2.basePath), !e2.buildId && e2.trailingSlash ? t2.endsWith("/") ? t2 : L(t2, "/") : M(t2);
        }
        formatSearch() {
          return this[B].url.search;
        }
        get buildId() {
          return this[B].buildId;
        }
        set buildId(e2) {
          this[B].buildId = e2;
        }
        get locale() {
          return this[B].locale ?? "";
        }
        set locale(e2) {
          var t2, r2;
          if (!this[B].locale || !(null == (r2 = this[B].options.nextConfig) ? void 0 : null == (t2 = r2.i18n) ? void 0 : t2.locales.includes(e2))) throw TypeError(`The NextURL configuration includes no locale "${e2}"`);
          this[B].locale = e2;
        }
        get defaultLocale() {
          return this[B].defaultLocale;
        }
        get domainLocale() {
          return this[B].domainLocale;
        }
        get searchParams() {
          return this[B].url.searchParams;
        }
        get host() {
          return this[B].url.host;
        }
        set host(e2) {
          this[B].url.host = e2;
        }
        get hostname() {
          return this[B].url.hostname;
        }
        set hostname(e2) {
          this[B].url.hostname = e2;
        }
        get port() {
          return this[B].url.port;
        }
        set port(e2) {
          this[B].url.port = e2;
        }
        get protocol() {
          return this[B].url.protocol;
        }
        set protocol(e2) {
          this[B].url.protocol = e2;
        }
        get href() {
          let e2 = this.formatPathname(), t2 = this.formatSearch();
          return `${this.protocol}//${this.host}${e2}${t2}${this.hash}`;
        }
        set href(e2) {
          this[B].url = V(e2), this.analyze();
        }
        get origin() {
          return this[B].url.origin;
        }
        get pathname() {
          return this[B].url.pathname;
        }
        set pathname(e2) {
          this[B].url.pathname = e2;
        }
        get hash() {
          return this[B].url.hash;
        }
        set hash(e2) {
          this[B].url.hash = e2;
        }
        get search() {
          return this[B].url.search;
        }
        set search(e2) {
          this[B].url.search = e2;
        }
        get password() {
          return this[B].url.password;
        }
        set password(e2) {
          this[B].url.password = e2;
        }
        get username() {
          return this[B].url.username;
        }
        set username(e2) {
          this[B].url.username = e2;
        }
        get basePath() {
          return this[B].basePath;
        }
        set basePath(e2) {
          this[B].basePath = e2.startsWith("/") ? e2 : `/${e2}`;
        }
        toString() {
          return this.href;
        }
        toJSON() {
          return this.href;
        }
        [Symbol.for("edge-runtime.inspect.custom")]() {
          return {
            href: this.href,
            origin: this.origin,
            protocol: this.protocol,
            username: this.username,
            password: this.password,
            host: this.host,
            hostname: this.hostname,
            port: this.port,
            pathname: this.pathname,
            search: this.search,
            searchParams: this.searchParams,
            hash: this.hash
          };
        }
        clone() {
          return new U(String(this), this[B].options);
        }
      }
      var q = r(447);
      let $ = Symbol("internal request");
      class G extends Request {
        constructor(e2, t2 = {}) {
          let r2 = "string" != typeof e2 && "url" in e2 ? e2.url : String(e2);
          O(r2), e2 instanceof Request ? super(e2, t2) : super(r2, t2);
          let n2 = new U(r2, {
            headers: P(this.headers),
            nextConfig: t2.nextConfig
          });
          this[$] = {
            cookies: new q.RequestCookies(this.headers),
            geo: t2.geo || {},
            ip: t2.ip,
            nextUrl: n2,
            url: n2.toString()
          };
        }
        [Symbol.for("edge-runtime.inspect.custom")]() {
          return {
            cookies: this.cookies,
            geo: this.geo,
            ip: this.ip,
            nextUrl: this.nextUrl,
            url: this.url,
            bodyUsed: this.bodyUsed,
            cache: this.cache,
            credentials: this.credentials,
            destination: this.destination,
            headers: Object.fromEntries(this.headers),
            integrity: this.integrity,
            keepalive: this.keepalive,
            method: this.method,
            mode: this.mode,
            redirect: this.redirect,
            referrer: this.referrer,
            referrerPolicy: this.referrerPolicy,
            signal: this.signal
          };
        }
        get cookies() {
          return this[$].cookies;
        }
        get geo() {
          return this[$].geo;
        }
        get ip() {
          return this[$].ip;
        }
        get nextUrl() {
          return this[$].nextUrl;
        }
        get page() {
          throw new x();
        }
        get ua() {
          throw new S();
        }
        get url() {
          return this[$].url;
        }
      }
      let H = Symbol("internal response"), F = /* @__PURE__ */ new Set([
        301,
        302,
        303,
        307,
        308
      ]);
      function z(e2, t2) {
        var r2;
        if (null == e2 ? void 0 : null == (r2 = e2.request) ? void 0 : r2.headers) {
          if (!(e2.request.headers instanceof Headers)) throw Error("request.headers must be an instance of Headers");
          let r3 = [];
          for (let [n2, i2] of e2.request.headers) t2.set("x-middleware-request-" + n2, i2), r3.push(n2);
          t2.set("x-middleware-override-headers", r3.join(","));
        }
      }
      class W extends Response {
        constructor(e2, t2 = {}) {
          super(e2, t2), this[H] = {
            cookies: new q.ResponseCookies(this.headers),
            url: t2.url ? new U(t2.url, {
              headers: P(this.headers),
              nextConfig: t2.nextConfig
            }) : void 0
          };
        }
        [Symbol.for("edge-runtime.inspect.custom")]() {
          return {
            cookies: this.cookies,
            url: this.url,
            body: this.body,
            bodyUsed: this.bodyUsed,
            headers: Object.fromEntries(this.headers),
            ok: this.ok,
            redirected: this.redirected,
            status: this.status,
            statusText: this.statusText,
            type: this.type
          };
        }
        get cookies() {
          return this[H].cookies;
        }
        static json(e2, t2) {
          let r2 = Response.json(e2, t2);
          return new W(r2.body, r2);
        }
        static redirect(e2, t2) {
          let r2 = "number" == typeof t2 ? t2 : (null == t2 ? void 0 : t2.status) ?? 307;
          if (!F.has(r2)) throw RangeError('Failed to execute "redirect" on "response": Invalid status code');
          let n2 = "object" == typeof t2 ? t2 : {}, i2 = new Headers(null == n2 ? void 0 : n2.headers);
          return i2.set("Location", O(e2)), new W(null, {
            ...n2,
            headers: i2,
            status: r2
          });
        }
        static rewrite(e2, t2) {
          let r2 = new Headers(null == t2 ? void 0 : t2.headers);
          return r2.set("x-middleware-rewrite", O(e2)), z(t2, r2), new W(null, {
            ...t2,
            headers: r2
          });
        }
        static next(e2) {
          let t2 = new Headers(null == e2 ? void 0 : e2.headers);
          return t2.set("x-middleware-next", "1"), z(e2, t2), new W(null, {
            ...e2,
            headers: t2
          });
        }
      }
      function K(e2, t2) {
        let r2 = "string" == typeof t2 ? new URL(t2) : t2, n2 = new URL(e2, t2), i2 = r2.protocol + "//" + r2.host;
        return n2.protocol + "//" + n2.host === i2 ? n2.toString().replace(i2, "") : n2.toString();
      }
      let X = [
        [
          "RSC"
        ],
        [
          "Next-Router-State-Tree"
        ],
        [
          "Next-Router-Prefetch"
        ]
      ];
      r(387);
      let Z = {
        client: "client",
        server: "server",
        edgeServer: "edge-server"
      };
      Z.client, Z.server, Z.edgeServer, Symbol("polyfills");
      let J = [
        "__nextFallback",
        "__nextLocale",
        "__nextInferredLocaleFromDefault",
        "__nextDefaultLocale",
        "__nextIsNotFound",
        "_rsc"
      ], Y = [
        "__nextDataReq"
      ], Q = "nxtP", ee = {
        shared: "shared",
        reactServerComponents: "rsc",
        serverSideRendering: "ssr",
        actionBrowser: "action-browser",
        api: "api",
        middleware: "middleware",
        instrument: "instrument",
        edgeAsset: "edge-asset",
        appPagesBrowser: "app-pages-browser",
        appMetadataRoute: "app-metadata-route",
        appRouteHandler: "app-route-handler"
      };
      ({
        ...ee,
        GROUP: {
          serverOnly: [
            ee.reactServerComponents,
            ee.actionBrowser,
            ee.appMetadataRoute,
            ee.appRouteHandler,
            ee.instrument
          ],
          clientOnly: [
            ee.serverSideRendering,
            ee.appPagesBrowser
          ],
          nonClientServerTarget: [
            ee.middleware,
            ee.api
          ],
          app: [
            ee.reactServerComponents,
            ee.actionBrowser,
            ee.appMetadataRoute,
            ee.appRouteHandler,
            ee.serverSideRendering,
            ee.appPagesBrowser,
            ee.shared,
            ee.instrument
          ]
        }
      });
      class et {
        static get(e2, t2, r2) {
          let n2 = Reflect.get(e2, t2, r2);
          return "function" == typeof n2 ? n2.bind(e2) : n2;
        }
        static set(e2, t2, r2, n2) {
          return Reflect.set(e2, t2, r2, n2);
        }
        static has(e2, t2) {
          return Reflect.has(e2, t2);
        }
        static deleteProperty(e2, t2) {
          return Reflect.deleteProperty(e2, t2);
        }
      }
      class er extends Error {
        constructor() {
          super("Headers cannot be modified. Read more: https://nextjs.org/docs/app/api-reference/functions/headers");
        }
        static callable() {
          throw new er();
        }
      }
      class en extends Headers {
        constructor(e2) {
          super(), this.headers = new Proxy(e2, {
            get(t2, r2, n2) {
              if ("symbol" == typeof r2) return et.get(t2, r2, n2);
              let i2 = r2.toLowerCase(), a2 = Object.keys(e2).find((e3) => e3.toLowerCase() === i2);
              if (void 0 !== a2) return et.get(t2, a2, n2);
            },
            set(t2, r2, n2, i2) {
              if ("symbol" == typeof r2) return et.set(t2, r2, n2, i2);
              let a2 = r2.toLowerCase(), o2 = Object.keys(e2).find((e3) => e3.toLowerCase() === a2);
              return et.set(t2, o2 ?? r2, n2, i2);
            },
            has(t2, r2) {
              if ("symbol" == typeof r2) return et.has(t2, r2);
              let n2 = r2.toLowerCase(), i2 = Object.keys(e2).find((e3) => e3.toLowerCase() === n2);
              return void 0 !== i2 && et.has(t2, i2);
            },
            deleteProperty(t2, r2) {
              if ("symbol" == typeof r2) return et.deleteProperty(t2, r2);
              let n2 = r2.toLowerCase(), i2 = Object.keys(e2).find((e3) => e3.toLowerCase() === n2);
              return void 0 === i2 || et.deleteProperty(t2, i2);
            }
          });
        }
        static seal(e2) {
          return new Proxy(e2, {
            get(e3, t2, r2) {
              switch (t2) {
                case "append":
                case "delete":
                case "set":
                  return er.callable;
                default:
                  return et.get(e3, t2, r2);
              }
            }
          });
        }
        merge(e2) {
          return Array.isArray(e2) ? e2.join(", ") : e2;
        }
        static from(e2) {
          return e2 instanceof Headers ? e2 : new en(e2);
        }
        append(e2, t2) {
          let r2 = this.headers[e2];
          "string" == typeof r2 ? this.headers[e2] = [
            r2,
            t2
          ] : Array.isArray(r2) ? r2.push(t2) : this.headers[e2] = t2;
        }
        delete(e2) {
          delete this.headers[e2];
        }
        get(e2) {
          let t2 = this.headers[e2];
          return void 0 !== t2 ? this.merge(t2) : null;
        }
        has(e2) {
          return void 0 !== this.headers[e2];
        }
        set(e2, t2) {
          this.headers[e2] = t2;
        }
        forEach(e2, t2) {
          for (let [r2, n2] of this.entries()) e2.call(t2, n2, r2, this);
        }
        *entries() {
          for (let e2 of Object.keys(this.headers)) {
            let t2 = e2.toLowerCase(), r2 = this.get(t2);
            yield [
              t2,
              r2
            ];
          }
        }
        *keys() {
          for (let e2 of Object.keys(this.headers)) {
            let t2 = e2.toLowerCase();
            yield t2;
          }
        }
        *values() {
          for (let e2 of Object.keys(this.headers)) {
            let t2 = this.get(e2);
            yield t2;
          }
        }
        [Symbol.iterator]() {
          return this.entries();
        }
      }
      let ei = Error("Invariant: AsyncLocalStorage accessed in runtime where it is not available");
      class ea {
        disable() {
          throw ei;
        }
        getStore() {
        }
        run() {
          throw ei;
        }
        exit() {
          throw ei;
        }
        enterWith() {
          throw ei;
        }
      }
      let eo = globalThis.AsyncLocalStorage;
      function es() {
        return eo ? new eo() : new ea();
      }
      let el = es();
      class eu extends Error {
        constructor() {
          super("Cookies can only be modified in a Server Action or Route Handler. Read more: https://nextjs.org/docs/app/api-reference/functions/cookies#cookiessetname-value-options");
        }
        static callable() {
          throw new eu();
        }
      }
      class ed {
        static seal(e2) {
          return new Proxy(e2, {
            get(e3, t2, r2) {
              switch (t2) {
                case "clear":
                case "delete":
                case "set":
                  return eu.callable;
                default:
                  return et.get(e3, t2, r2);
              }
            }
          });
        }
      }
      let ec = Symbol.for("next.mutated.cookies");
      class ep {
        static wrap(e2, t2) {
          let r2 = new q.ResponseCookies(new Headers());
          for (let t3 of e2.getAll()) r2.set(t3);
          let n2 = [], i2 = /* @__PURE__ */ new Set(), a2 = () => {
            let e3 = el.getStore();
            if (e3 && (e3.pathWasRevalidated = true), n2 = r2.getAll().filter((e4) => i2.has(e4.name)), t2) {
              let e4 = [];
              for (let t3 of n2) {
                let r3 = new q.ResponseCookies(new Headers());
                r3.set(t3), e4.push(r3.toString());
              }
              t2(e4);
            }
          };
          return new Proxy(r2, {
            get(e3, t3, r3) {
              switch (t3) {
                case ec:
                  return n2;
                case "delete":
                  return function(...t4) {
                    i2.add("string" == typeof t4[0] ? t4[0] : t4[0].name);
                    try {
                      e3.delete(...t4);
                    } finally {
                      a2();
                    }
                  };
                case "set":
                  return function(...t4) {
                    i2.add("string" == typeof t4[0] ? t4[0] : t4[0].name);
                    try {
                      return e3.set(...t4);
                    } finally {
                      a2();
                    }
                  };
                default:
                  return et.get(e3, t3, r3);
              }
            }
          });
        }
      }
      !function(e2) {
        e2.handleRequest = "BaseServer.handleRequest", e2.run = "BaseServer.run", e2.pipe = "BaseServer.pipe", e2.getStaticHTML = "BaseServer.getStaticHTML", e2.render = "BaseServer.render", e2.renderToResponseWithComponents = "BaseServer.renderToResponseWithComponents", e2.renderToResponse = "BaseServer.renderToResponse", e2.renderToHTML = "BaseServer.renderToHTML", e2.renderError = "BaseServer.renderError", e2.renderErrorToResponse = "BaseServer.renderErrorToResponse", e2.renderErrorToHTML = "BaseServer.renderErrorToHTML", e2.render404 = "BaseServer.render404";
      }(i || (i = {})), function(e2) {
        e2.loadDefaultErrorComponents = "LoadComponents.loadDefaultErrorComponents", e2.loadComponents = "LoadComponents.loadComponents";
      }(a || (a = {})), function(e2) {
        e2.getRequestHandler = "NextServer.getRequestHandler", e2.getServer = "NextServer.getServer", e2.getServerRequestHandler = "NextServer.getServerRequestHandler", e2.createServer = "createServer.createServer";
      }(o || (o = {})), function(e2) {
        e2.compression = "NextNodeServer.compression", e2.getBuildId = "NextNodeServer.getBuildId", e2.createComponentTree = "NextNodeServer.createComponentTree", e2.clientComponentLoading = "NextNodeServer.clientComponentLoading", e2.getLayoutOrPageModule = "NextNodeServer.getLayoutOrPageModule", e2.generateStaticRoutes = "NextNodeServer.generateStaticRoutes", e2.generateFsStaticRoutes = "NextNodeServer.generateFsStaticRoutes", e2.generatePublicRoutes = "NextNodeServer.generatePublicRoutes", e2.generateImageRoutes = "NextNodeServer.generateImageRoutes.route", e2.sendRenderResult = "NextNodeServer.sendRenderResult", e2.proxyRequest = "NextNodeServer.proxyRequest", e2.runApi = "NextNodeServer.runApi", e2.render = "NextNodeServer.render", e2.renderHTML = "NextNodeServer.renderHTML", e2.imageOptimizer = "NextNodeServer.imageOptimizer", e2.getPagePath = "NextNodeServer.getPagePath", e2.getRoutesManifest = "NextNodeServer.getRoutesManifest", e2.findPageComponents = "NextNodeServer.findPageComponents", e2.getFontManifest = "NextNodeServer.getFontManifest", e2.getServerComponentManifest = "NextNodeServer.getServerComponentManifest", e2.getRequestHandler = "NextNodeServer.getRequestHandler", e2.renderToHTML = "NextNodeServer.renderToHTML", e2.renderError = "NextNodeServer.renderError", e2.renderErrorToHTML = "NextNodeServer.renderErrorToHTML", e2.render404 = "NextNodeServer.render404", e2.startResponse = "NextNodeServer.startResponse", e2.route = "route", e2.onProxyReq = "onProxyReq", e2.apiResolver = "apiResolver", e2.internalFetch = "internalFetch";
      }(s || (s = {})), (l || (l = {})).startServer = "startServer.startServer", function(e2) {
        e2.getServerSideProps = "Render.getServerSideProps", e2.getStaticProps = "Render.getStaticProps", e2.renderToString = "Render.renderToString", e2.renderDocument = "Render.renderDocument", e2.createBodyResult = "Render.createBodyResult";
      }(u || (u = {})), function(e2) {
        e2.renderToString = "AppRender.renderToString", e2.renderToReadableStream = "AppRender.renderToReadableStream", e2.getBodyResult = "AppRender.getBodyResult", e2.fetch = "AppRender.fetch";
      }(d || (d = {})), (c || (c = {})).executeRoute = "Router.executeRoute", (p || (p = {})).runHandler = "Node.runHandler", (g || (g = {})).runHandler = "AppRouteRouteHandlers.runHandler", function(e2) {
        e2.generateMetadata = "ResolveMetadata.generateMetadata", e2.generateViewport = "ResolveMetadata.generateViewport";
      }(h || (h = {})), (f || (f = {})).execute = "Middleware.execute";
      let eg = [
        "Middleware.execute",
        "BaseServer.handleRequest",
        "Render.getServerSideProps",
        "Render.getStaticProps",
        "AppRender.fetch",
        "AppRender.getBodyResult",
        "Render.renderDocument",
        "Node.runHandler",
        "AppRouteRouteHandlers.runHandler",
        "ResolveMetadata.generateMetadata",
        "ResolveMetadata.generateViewport",
        "NextNodeServer.createComponentTree",
        "NextNodeServer.findPageComponents",
        "NextNodeServer.getLayoutOrPageModule",
        "NextNodeServer.startResponse",
        "NextNodeServer.clientComponentLoading"
      ], eh = [
        "NextNodeServer.findPageComponents",
        "NextNodeServer.createComponentTree",
        "NextNodeServer.clientComponentLoading"
      ], { context: ef, propagation: eb, trace: em, SpanStatusCode: ev, SpanKind: ew, ROOT_CONTEXT: ey } = n = r(692), e_ = (e2) => null !== e2 && "object" == typeof e2 && "function" == typeof e2.then, ex = (e2, t2) => {
        (null == t2 ? void 0 : t2.bubble) === true ? e2.setAttribute("next.bubble", true) : (t2 && e2.recordException(t2), e2.setStatus({
          code: ev.ERROR,
          message: null == t2 ? void 0 : t2.message
        })), e2.end();
      }, eS = /* @__PURE__ */ new Map(), eP = n.createContextKey("next.rootSpanId"), eO = 0, eN = () => eO++;
      class eR {
        getTracerInstance() {
          return em.getTracer("next.js", "0.0.1");
        }
        getContext() {
          return ef;
        }
        getActiveScopeSpan() {
          return em.getSpan(null == ef ? void 0 : ef.active());
        }
        withPropagatedContext(e2, t2, r2) {
          let n2 = ef.active();
          if (em.getSpanContext(n2)) return t2();
          let i2 = eb.extract(n2, e2, r2);
          return ef.with(i2, t2);
        }
        trace(...e2) {
          var t2;
          let [r2, n2, i2] = e2, { fn: a2, options: o2 } = "function" == typeof n2 ? {
            fn: n2,
            options: {}
          } : {
            fn: i2,
            options: {
              ...n2
            }
          }, s2 = o2.spanName ?? r2;
          if (!eg.includes(r2) && "1" !== process.env.NEXT_OTEL_VERBOSE || o2.hideSpan) return a2();
          let l2 = this.getSpanContext((null == o2 ? void 0 : o2.parentSpan) ?? this.getActiveScopeSpan()), u2 = false;
          l2 ? (null == (t2 = em.getSpanContext(l2)) ? void 0 : t2.isRemote) && (u2 = true) : (l2 = (null == ef ? void 0 : ef.active()) ?? ey, u2 = true);
          let d2 = eN();
          return o2.attributes = {
            "next.span_name": s2,
            "next.span_type": r2,
            ...o2.attributes
          }, ef.with(l2.setValue(eP, d2), () => this.getTracerInstance().startActiveSpan(s2, o2, (e3) => {
            let t3 = "performance" in globalThis ? globalThis.performance.now() : void 0, n3 = () => {
              eS.delete(d2), t3 && process.env.NEXT_OTEL_PERFORMANCE_PREFIX && eh.includes(r2 || "") && performance.measure(`${process.env.NEXT_OTEL_PERFORMANCE_PREFIX}:next-${(r2.split(".").pop() || "").replace(/[A-Z]/g, (e4) => "-" + e4.toLowerCase())}`, {
                start: t3,
                end: performance.now()
              });
            };
            u2 && eS.set(d2, new Map(Object.entries(o2.attributes ?? {})));
            try {
              if (a2.length > 1) return a2(e3, (t5) => ex(e3, t5));
              let t4 = a2(e3);
              if (e_(t4)) return t4.then((t5) => (e3.end(), t5)).catch((t5) => {
                throw ex(e3, t5), t5;
              }).finally(n3);
              return e3.end(), n3(), t4;
            } catch (t4) {
              throw ex(e3, t4), n3(), t4;
            }
          }));
        }
        wrap(...e2) {
          let t2 = this, [r2, n2, i2] = 3 === e2.length ? e2 : [
            e2[0],
            {},
            e2[1]
          ];
          return eg.includes(r2) || "1" === process.env.NEXT_OTEL_VERBOSE ? function() {
            let e3 = n2;
            "function" == typeof e3 && "function" == typeof i2 && (e3 = e3.apply(this, arguments));
            let a2 = arguments.length - 1, o2 = arguments[a2];
            if ("function" != typeof o2) return t2.trace(r2, e3, () => i2.apply(this, arguments));
            {
              let n3 = t2.getContext().bind(ef.active(), o2);
              return t2.trace(r2, e3, (e4, t3) => (arguments[a2] = function(e5) {
                return null == t3 || t3(e5), n3.apply(this, arguments);
              }, i2.apply(this, arguments)));
            }
          } : i2;
        }
        startSpan(...e2) {
          let [t2, r2] = e2, n2 = this.getSpanContext((null == r2 ? void 0 : r2.parentSpan) ?? this.getActiveScopeSpan());
          return this.getTracerInstance().startSpan(t2, r2, n2);
        }
        getSpanContext(e2) {
          return e2 ? em.setSpan(ef.active(), e2) : void 0;
        }
        getRootSpanAttributes() {
          let e2 = ef.active().getValue(eP);
          return eS.get(e2);
        }
      }
      let eT = (() => {
        let e2 = new eR();
        return () => e2;
      })(), eC = "__prerender_bypass";
      Symbol("__next_preview_data"), Symbol(eC);
      class eE {
        constructor(e2, t2, r2, n2) {
          var i2;
          let a2 = e2 && function(e3, t3) {
            let r3 = en.from(e3.headers);
            return {
              isOnDemandRevalidate: r3.get("x-prerender-revalidate") === t3.previewModeId,
              revalidateOnlyGenerated: r3.has("x-prerender-revalidate-if-generated")
            };
          }(t2, e2).isOnDemandRevalidate, o2 = null == (i2 = r2.get(eC)) ? void 0 : i2.value;
          this.isEnabled = !!(!a2 && o2 && e2 && o2 === e2.previewModeId), this._previewModeId = null == e2 ? void 0 : e2.previewModeId, this._mutableCookies = n2;
        }
        enable() {
          if (!this._previewModeId) throw Error("Invariant: previewProps missing previewModeId this should never happen");
          this._mutableCookies.set({
            name: eC,
            value: this._previewModeId,
            httpOnly: true,
            sameSite: "none",
            secure: true,
            path: "/"
          });
        }
        disable() {
          this._mutableCookies.set({
            name: eC,
            value: "",
            httpOnly: true,
            sameSite: "none",
            secure: true,
            path: "/",
            expires: /* @__PURE__ */ new Date(0)
          });
        }
      }
      let eM = {
        wrap(e2, { req: t2, res: r2, renderOpts: n2 }, i2) {
          let a2;
          function o2(e3) {
            r2 && r2.setHeader("Set-Cookie", e3);
          }
          n2 && "previewProps" in n2 && (a2 = n2.previewProps);
          let s2 = {}, l2 = {
            get headers() {
              return s2.headers || (s2.headers = function(e3) {
                let t3 = en.from(e3);
                for (let e4 of X) t3.delete(e4.toString().toLowerCase());
                return en.seal(t3);
              }(t2.headers)), s2.headers;
            },
            get cookies() {
              return s2.cookies || (s2.cookies = function(e3) {
                let t3 = new q.RequestCookies(en.from(e3));
                return ed.seal(t3);
              }(t2.headers)), s2.cookies;
            },
            get mutableCookies() {
              return s2.mutableCookies || (s2.mutableCookies = function(e3, t3) {
                let r3 = new q.RequestCookies(en.from(e3));
                return ep.wrap(r3, t3);
              }(t2.headers, (null == n2 ? void 0 : n2.onUpdateCookies) || (r2 ? o2 : void 0))), s2.mutableCookies;
            },
            get draftMode() {
              return s2.draftMode || (s2.draftMode = new eE(a2, t2, this.cookies, this.mutableCookies)), s2.draftMode;
            },
            reactLoadableManifest: (null == n2 ? void 0 : n2.reactLoadableManifest) || {},
            assetPrefix: (null == n2 ? void 0 : n2.assetPrefix) || ""
          };
          return e2.run(l2, i2, l2);
        }
      }, eI = es();
      class eA extends G {
        constructor(e2) {
          super(e2.input, e2.init), this.sourcePage = e2.page;
        }
        get request() {
          throw new _({
            page: this.sourcePage
          });
        }
        respondWith() {
          throw new _({
            page: this.sourcePage
          });
        }
        waitUntil() {
          throw new _({
            page: this.sourcePage
          });
        }
      }
      let eL = {
        keys: (e2) => Array.from(e2.keys()),
        get: (e2, t2) => e2.get(t2) ?? void 0
      }, ek = (e2, t2) => eT().withPropagatedContext(e2.headers, t2, eL), ej = false;
      async function eD(e2) {
        let t2, n2;
        !function() {
          if (!ej && (ej = true, "true" === process.env.NEXT_PRIVATE_TEST_PROXY)) {
            let { interceptTestApis: e3, wrapRequestHandler: t3 } = r(311);
            e3(), ek = t3(ek);
          }
        }(), await w();
        let i2 = void 0 !== self.__BUILD_MANIFEST, a2 = "string" == typeof self.__PRERENDER_MANIFEST ? JSON.parse(self.__PRERENDER_MANIFEST) : void 0;
        e2.request.url = e2.request.url.replace(/\.rsc($|\?)/, "$1");
        let o2 = new U(e2.request.url, {
          headers: e2.request.headers,
          nextConfig: e2.request.nextConfig
        });
        for (let e3 of [
          ...o2.searchParams.keys()
        ]) {
          let t3 = o2.searchParams.getAll(e3);
          if (e3 !== Q && e3.startsWith(Q)) {
            let r2 = e3.substring(Q.length);
            for (let e4 of (o2.searchParams.delete(r2), t3)) o2.searchParams.append(r2, e4);
            o2.searchParams.delete(e3);
          }
        }
        let s2 = o2.buildId;
        o2.buildId = "";
        let l2 = e2.request.headers["x-nextjs-data"];
        l2 && "/index" === o2.pathname && (o2.pathname = "/");
        let u2 = function(e3) {
          let t3 = new Headers();
          for (let [r2, n3] of Object.entries(e3)) for (let e4 of Array.isArray(n3) ? n3 : [
            n3
          ]) void 0 !== e4 && ("number" == typeof e4 && (e4 = e4.toString()), t3.append(r2, e4));
          return t3;
        }(e2.request.headers), d2 = /* @__PURE__ */ new Map();
        if (!i2) for (let e3 of X) {
          let t3 = e3.toString().toLowerCase();
          u2.get(t3) && (d2.set(t3, u2.get(t3)), u2.delete(t3));
        }
        let c2 = new eA({
          page: e2.page,
          input: function(e3, t3) {
            let r2 = "string" == typeof e3, n3 = r2 ? new URL(e3) : e3;
            for (let e4 of J) n3.searchParams.delete(e4);
            if (t3) for (let e4 of Y) n3.searchParams.delete(e4);
            return r2 ? n3.toString() : n3;
          }(o2, true).toString(),
          init: {
            body: e2.request.body,
            geo: e2.request.geo,
            headers: u2,
            ip: e2.request.ip,
            method: e2.request.method,
            nextConfig: e2.request.nextConfig,
            signal: e2.request.signal
          }
        });
        l2 && Object.defineProperty(c2, "__isData", {
          enumerable: false,
          value: true
        }), !globalThis.__incrementalCache && e2.IncrementalCache && (globalThis.__incrementalCache = new e2.IncrementalCache({
          appDir: true,
          fetchCache: true,
          minimalMode: true,
          fetchCacheKeyPrefix: "",
          dev: false,
          requestHeaders: e2.request.headers,
          requestProtocol: "https",
          getPrerenderManifest: () => ({
            version: -1,
            routes: {},
            dynamicRoutes: {},
            notFoundRoutes: [],
            preview: {
              previewModeId: "development-id"
            }
          })
        }));
        let p2 = new E({
          request: c2,
          page: e2.page
        });
        if ((t2 = await ek(c2, () => "/middleware" === e2.page || "/src/middleware" === e2.page ? eT().trace(f.execute, {
          spanName: `middleware ${c2.method} ${c2.nextUrl.pathname}`,
          attributes: {
            "http.target": c2.nextUrl.pathname,
            "http.method": c2.method
          }
        }, () => eM.wrap(eI, {
          req: c2,
          renderOpts: {
            onUpdateCookies: (e3) => {
              n2 = e3;
            },
            previewProps: (null == a2 ? void 0 : a2.preview) || {
              previewModeId: "development-id",
              previewModeEncryptionKey: "",
              previewModeSigningKey: ""
            }
          }
        }, () => e2.handler(c2, p2))) : e2.handler(c2, p2))) && !(t2 instanceof Response)) throw TypeError("Expected an instance of Response to be returned");
        t2 && n2 && t2.headers.set("set-cookie", n2);
        let g2 = null == t2 ? void 0 : t2.headers.get("x-middleware-rewrite");
        if (t2 && g2) {
          let r2 = new U(g2, {
            forceLocale: true,
            headers: e2.request.headers,
            nextConfig: e2.request.nextConfig
          });
          r2.host === c2.nextUrl.host && (r2.buildId = s2 || r2.buildId, t2.headers.set("x-middleware-rewrite", String(r2)));
          let n3 = K(String(r2), String(o2));
          l2 && t2.headers.set("x-nextjs-rewrite", n3);
        }
        let h2 = null == t2 ? void 0 : t2.headers.get("Location");
        if (t2 && h2 && !i2) {
          let r2 = new U(h2, {
            forceLocale: false,
            headers: e2.request.headers,
            nextConfig: e2.request.nextConfig
          });
          t2 = new Response(t2.body, t2), r2.host === c2.nextUrl.host && (r2.buildId = s2 || r2.buildId, t2.headers.set("Location", String(r2))), l2 && (t2.headers.delete("Location"), t2.headers.set("x-nextjs-redirect", K(String(r2), String(o2))));
        }
        let b2 = t2 || W.next(), m2 = b2.headers.get("x-middleware-override-headers"), v2 = [];
        if (m2) {
          for (let [e3, t3] of d2) b2.headers.set(`x-middleware-request-${e3}`, t3), v2.push(e3);
          v2.length > 0 && b2.headers.set("x-middleware-override-headers", m2 + "," + v2.join(","));
        }
        return {
          response: b2,
          waitUntil: Promise.all(p2[T]),
          fetchMetrics: c2.fetchMetrics
        };
      }
      r(568), "undefined" == typeof URLPattern || URLPattern;
      let eV = [
        "/login",
        "/forgot-password",
        "/pricing",
        "/test-login",
        "/test-bare"
      ];
      function eB(e2) {
        let { pathname: t2 } = e2.nextUrl;
        if (t2.startsWith("/_next") || t2.startsWith("/api") || t2.startsWith("/favicon") || t2.includes(".") || eV.some((e3) => t2 === e3 || t2.startsWith(e3 + "/"))) return W.next();
        let r2 = e2.cookies.get("__session") ?? e2.cookies.get("educonnect-token");
        if (!r2?.value) {
          let r3 = new URL("/login", e2.url);
          return r3.searchParams.set("redirect", t2), W.redirect(r3);
        }
        return W.next();
      }
      let eU = {
        matcher: [
          "/((?!_next/static|_next/image|favicon.ico).*)"
        ]
      }, eq = {
        ...b
      }, e$ = eq.middleware || eq.default, eG = "/middleware";
      if ("function" != typeof e$) throw Error(`The Middleware "${eG}" must export a \`middleware\` or a \`default\` function`);
      function eH(e2) {
        return eD({
          ...e2,
          page: eG,
          handler: e$
        });
      }
    },
    447: (e) => {
      "use strict";
      var t = Object.defineProperty, r = Object.getOwnPropertyDescriptor, n = Object.getOwnPropertyNames, i = Object.prototype.hasOwnProperty, a = {};
      function o(e2) {
        var t2;
        let r2 = [
          "path" in e2 && e2.path && `Path=${e2.path}`,
          "expires" in e2 && (e2.expires || 0 === e2.expires) && `Expires=${("number" == typeof e2.expires ? new Date(e2.expires) : e2.expires).toUTCString()}`,
          "maxAge" in e2 && "number" == typeof e2.maxAge && `Max-Age=${e2.maxAge}`,
          "domain" in e2 && e2.domain && `Domain=${e2.domain}`,
          "secure" in e2 && e2.secure && "Secure",
          "httpOnly" in e2 && e2.httpOnly && "HttpOnly",
          "sameSite" in e2 && e2.sameSite && `SameSite=${e2.sameSite}`,
          "partitioned" in e2 && e2.partitioned && "Partitioned",
          "priority" in e2 && e2.priority && `Priority=${e2.priority}`
        ].filter(Boolean), n2 = `${e2.name}=${encodeURIComponent(null != (t2 = e2.value) ? t2 : "")}`;
        return 0 === r2.length ? n2 : `${n2}; ${r2.join("; ")}`;
      }
      function s(e2) {
        let t2 = /* @__PURE__ */ new Map();
        for (let r2 of e2.split(/; */)) {
          if (!r2) continue;
          let e3 = r2.indexOf("=");
          if (-1 === e3) {
            t2.set(r2, "true");
            continue;
          }
          let [n2, i2] = [
            r2.slice(0, e3),
            r2.slice(e3 + 1)
          ];
          try {
            t2.set(n2, decodeURIComponent(null != i2 ? i2 : "true"));
          } catch {
          }
        }
        return t2;
      }
      function l(e2) {
        var t2, r2;
        if (!e2) return;
        let [[n2, i2], ...a2] = s(e2), { domain: o2, expires: l2, httponly: c2, maxage: p2, path: g, samesite: h, secure: f, partitioned: b, priority: m } = Object.fromEntries(a2.map(([e3, t3]) => [
          e3.toLowerCase(),
          t3
        ]));
        return function(e3) {
          let t3 = {};
          for (let r3 in e3) e3[r3] && (t3[r3] = e3[r3]);
          return t3;
        }({
          name: n2,
          value: decodeURIComponent(i2),
          domain: o2,
          ...l2 && {
            expires: new Date(l2)
          },
          ...c2 && {
            httpOnly: true
          },
          ..."string" == typeof p2 && {
            maxAge: Number(p2)
          },
          path: g,
          ...h && {
            sameSite: u.includes(t2 = (t2 = h).toLowerCase()) ? t2 : void 0
          },
          ...f && {
            secure: true
          },
          ...m && {
            priority: d.includes(r2 = (r2 = m).toLowerCase()) ? r2 : void 0
          },
          ...b && {
            partitioned: true
          }
        });
      }
      ((e2, r2) => {
        for (var n2 in r2) t(e2, n2, {
          get: r2[n2],
          enumerable: true
        });
      })(a, {
        RequestCookies: () => c,
        ResponseCookies: () => p,
        parseCookie: () => s,
        parseSetCookie: () => l,
        stringifyCookie: () => o
      }), e.exports = ((e2, a2, o2, s2) => {
        if (a2 && "object" == typeof a2 || "function" == typeof a2) for (let l2 of n(a2)) i.call(e2, l2) || l2 === o2 || t(e2, l2, {
          get: () => a2[l2],
          enumerable: !(s2 = r(a2, l2)) || s2.enumerable
        });
        return e2;
      })(t({}, "__esModule", {
        value: true
      }), a);
      var u = [
        "strict",
        "lax",
        "none"
      ], d = [
        "low",
        "medium",
        "high"
      ], c = class {
        constructor(e2) {
          this._parsed = /* @__PURE__ */ new Map(), this._headers = e2;
          let t2 = e2.get("cookie");
          if (t2) for (let [e3, r2] of s(t2)) this._parsed.set(e3, {
            name: e3,
            value: r2
          });
        }
        [Symbol.iterator]() {
          return this._parsed[Symbol.iterator]();
        }
        get size() {
          return this._parsed.size;
        }
        get(...e2) {
          let t2 = "string" == typeof e2[0] ? e2[0] : e2[0].name;
          return this._parsed.get(t2);
        }
        getAll(...e2) {
          var t2;
          let r2 = Array.from(this._parsed);
          if (!e2.length) return r2.map(([e3, t3]) => t3);
          let n2 = "string" == typeof e2[0] ? e2[0] : null == (t2 = e2[0]) ? void 0 : t2.name;
          return r2.filter(([e3]) => e3 === n2).map(([e3, t3]) => t3);
        }
        has(e2) {
          return this._parsed.has(e2);
        }
        set(...e2) {
          let [t2, r2] = 1 === e2.length ? [
            e2[0].name,
            e2[0].value
          ] : e2, n2 = this._parsed;
          return n2.set(t2, {
            name: t2,
            value: r2
          }), this._headers.set("cookie", Array.from(n2).map(([e3, t3]) => o(t3)).join("; ")), this;
        }
        delete(e2) {
          let t2 = this._parsed, r2 = Array.isArray(e2) ? e2.map((e3) => t2.delete(e3)) : t2.delete(e2);
          return this._headers.set("cookie", Array.from(t2).map(([e3, t3]) => o(t3)).join("; ")), r2;
        }
        clear() {
          return this.delete(Array.from(this._parsed.keys())), this;
        }
        [Symbol.for("edge-runtime.inspect.custom")]() {
          return `RequestCookies ${JSON.stringify(Object.fromEntries(this._parsed))}`;
        }
        toString() {
          return [
            ...this._parsed.values()
          ].map((e2) => `${e2.name}=${encodeURIComponent(e2.value)}`).join("; ");
        }
      }, p = class {
        constructor(e2) {
          var t2, r2, n2;
          this._parsed = /* @__PURE__ */ new Map(), this._headers = e2;
          let i2 = null != (n2 = null != (r2 = null == (t2 = e2.getSetCookie) ? void 0 : t2.call(e2)) ? r2 : e2.get("set-cookie")) ? n2 : [];
          for (let e3 of Array.isArray(i2) ? i2 : function(e4) {
            if (!e4) return [];
            var t3, r3, n3, i3, a2, o2 = [], s2 = 0;
            function l2() {
              for (; s2 < e4.length && /\s/.test(e4.charAt(s2)); ) s2 += 1;
              return s2 < e4.length;
            }
            for (; s2 < e4.length; ) {
              for (t3 = s2, a2 = false; l2(); ) if ("," === (r3 = e4.charAt(s2))) {
                for (n3 = s2, s2 += 1, l2(), i3 = s2; s2 < e4.length && "=" !== (r3 = e4.charAt(s2)) && ";" !== r3 && "," !== r3; ) s2 += 1;
                s2 < e4.length && "=" === e4.charAt(s2) ? (a2 = true, s2 = i3, o2.push(e4.substring(t3, n3)), t3 = s2) : s2 = n3 + 1;
              } else s2 += 1;
              (!a2 || s2 >= e4.length) && o2.push(e4.substring(t3, e4.length));
            }
            return o2;
          }(i2)) {
            let t3 = l(e3);
            t3 && this._parsed.set(t3.name, t3);
          }
        }
        get(...e2) {
          let t2 = "string" == typeof e2[0] ? e2[0] : e2[0].name;
          return this._parsed.get(t2);
        }
        getAll(...e2) {
          var t2;
          let r2 = Array.from(this._parsed.values());
          if (!e2.length) return r2;
          let n2 = "string" == typeof e2[0] ? e2[0] : null == (t2 = e2[0]) ? void 0 : t2.name;
          return r2.filter((e3) => e3.name === n2);
        }
        has(e2) {
          return this._parsed.has(e2);
        }
        set(...e2) {
          let [t2, r2, n2] = 1 === e2.length ? [
            e2[0].name,
            e2[0].value,
            e2[0]
          ] : e2, i2 = this._parsed;
          return i2.set(t2, function(e3 = {
            name: "",
            value: ""
          }) {
            return "number" == typeof e3.expires && (e3.expires = new Date(e3.expires)), e3.maxAge && (e3.expires = new Date(Date.now() + 1e3 * e3.maxAge)), (null === e3.path || void 0 === e3.path) && (e3.path = "/"), e3;
          }({
            name: t2,
            value: r2,
            ...n2
          })), function(e3, t3) {
            for (let [, r3] of (t3.delete("set-cookie"), e3)) {
              let e4 = o(r3);
              t3.append("set-cookie", e4);
            }
          }(i2, this._headers), this;
        }
        delete(...e2) {
          let [t2, r2, n2] = "string" == typeof e2[0] ? [
            e2[0]
          ] : [
            e2[0].name,
            e2[0].path,
            e2[0].domain
          ];
          return this.set({
            name: t2,
            path: r2,
            domain: n2,
            value: "",
            expires: /* @__PURE__ */ new Date(0)
          });
        }
        [Symbol.for("edge-runtime.inspect.custom")]() {
          return `ResponseCookies ${JSON.stringify(Object.fromEntries(this._parsed))}`;
        }
        toString() {
          return [
            ...this._parsed.values()
          ].map(o).join("; ");
        }
      };
    },
    692: (e, t, r) => {
      (() => {
        "use strict";
        var t2 = {
          491: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.ContextAPI = void 0;
            let n2 = r2(223), i2 = r2(172), a2 = r2(930), o = "context", s = new n2.NoopContextManager();
            class l {
              constructor() {
              }
              static getInstance() {
                return this._instance || (this._instance = new l()), this._instance;
              }
              setGlobalContextManager(e3) {
                return (0, i2.registerGlobal)(o, e3, a2.DiagAPI.instance());
              }
              active() {
                return this._getContextManager().active();
              }
              with(e3, t4, r3, ...n3) {
                return this._getContextManager().with(e3, t4, r3, ...n3);
              }
              bind(e3, t4) {
                return this._getContextManager().bind(e3, t4);
              }
              _getContextManager() {
                return (0, i2.getGlobal)(o) || s;
              }
              disable() {
                this._getContextManager().disable(), (0, i2.unregisterGlobal)(o, a2.DiagAPI.instance());
              }
            }
            t3.ContextAPI = l;
          },
          930: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.DiagAPI = void 0;
            let n2 = r2(56), i2 = r2(912), a2 = r2(957), o = r2(172);
            class s {
              constructor() {
                function e3(e4) {
                  return function(...t5) {
                    let r3 = (0, o.getGlobal)("diag");
                    if (r3) return r3[e4](...t5);
                  };
                }
                let t4 = this;
                t4.setLogger = (e4, r3 = {
                  logLevel: a2.DiagLogLevel.INFO
                }) => {
                  var n3, s2, l;
                  if (e4 === t4) {
                    let e5 = Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
                    return t4.error(null !== (n3 = e5.stack) && void 0 !== n3 ? n3 : e5.message), false;
                  }
                  "number" == typeof r3 && (r3 = {
                    logLevel: r3
                  });
                  let u = (0, o.getGlobal)("diag"), d = (0, i2.createLogLevelDiagLogger)(null !== (s2 = r3.logLevel) && void 0 !== s2 ? s2 : a2.DiagLogLevel.INFO, e4);
                  if (u && !r3.suppressOverrideMessage) {
                    let e5 = null !== (l = Error().stack) && void 0 !== l ? l : "<failed to generate stacktrace>";
                    u.warn(`Current logger will be overwritten from ${e5}`), d.warn(`Current logger will overwrite one already registered from ${e5}`);
                  }
                  return (0, o.registerGlobal)("diag", d, t4, true);
                }, t4.disable = () => {
                  (0, o.unregisterGlobal)("diag", t4);
                }, t4.createComponentLogger = (e4) => new n2.DiagComponentLogger(e4), t4.verbose = e3("verbose"), t4.debug = e3("debug"), t4.info = e3("info"), t4.warn = e3("warn"), t4.error = e3("error");
              }
              static instance() {
                return this._instance || (this._instance = new s()), this._instance;
              }
            }
            t3.DiagAPI = s;
          },
          653: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.MetricsAPI = void 0;
            let n2 = r2(660), i2 = r2(172), a2 = r2(930), o = "metrics";
            class s {
              constructor() {
              }
              static getInstance() {
                return this._instance || (this._instance = new s()), this._instance;
              }
              setGlobalMeterProvider(e3) {
                return (0, i2.registerGlobal)(o, e3, a2.DiagAPI.instance());
              }
              getMeterProvider() {
                return (0, i2.getGlobal)(o) || n2.NOOP_METER_PROVIDER;
              }
              getMeter(e3, t4, r3) {
                return this.getMeterProvider().getMeter(e3, t4, r3);
              }
              disable() {
                (0, i2.unregisterGlobal)(o, a2.DiagAPI.instance());
              }
            }
            t3.MetricsAPI = s;
          },
          181: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.PropagationAPI = void 0;
            let n2 = r2(172), i2 = r2(874), a2 = r2(194), o = r2(277), s = r2(369), l = r2(930), u = "propagation", d = new i2.NoopTextMapPropagator();
            class c {
              constructor() {
                this.createBaggage = s.createBaggage, this.getBaggage = o.getBaggage, this.getActiveBaggage = o.getActiveBaggage, this.setBaggage = o.setBaggage, this.deleteBaggage = o.deleteBaggage;
              }
              static getInstance() {
                return this._instance || (this._instance = new c()), this._instance;
              }
              setGlobalPropagator(e3) {
                return (0, n2.registerGlobal)(u, e3, l.DiagAPI.instance());
              }
              inject(e3, t4, r3 = a2.defaultTextMapSetter) {
                return this._getGlobalPropagator().inject(e3, t4, r3);
              }
              extract(e3, t4, r3 = a2.defaultTextMapGetter) {
                return this._getGlobalPropagator().extract(e3, t4, r3);
              }
              fields() {
                return this._getGlobalPropagator().fields();
              }
              disable() {
                (0, n2.unregisterGlobal)(u, l.DiagAPI.instance());
              }
              _getGlobalPropagator() {
                return (0, n2.getGlobal)(u) || d;
              }
            }
            t3.PropagationAPI = c;
          },
          997: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.TraceAPI = void 0;
            let n2 = r2(172), i2 = r2(846), a2 = r2(139), o = r2(607), s = r2(930), l = "trace";
            class u {
              constructor() {
                this._proxyTracerProvider = new i2.ProxyTracerProvider(), this.wrapSpanContext = a2.wrapSpanContext, this.isSpanContextValid = a2.isSpanContextValid, this.deleteSpan = o.deleteSpan, this.getSpan = o.getSpan, this.getActiveSpan = o.getActiveSpan, this.getSpanContext = o.getSpanContext, this.setSpan = o.setSpan, this.setSpanContext = o.setSpanContext;
              }
              static getInstance() {
                return this._instance || (this._instance = new u()), this._instance;
              }
              setGlobalTracerProvider(e3) {
                let t4 = (0, n2.registerGlobal)(l, this._proxyTracerProvider, s.DiagAPI.instance());
                return t4 && this._proxyTracerProvider.setDelegate(e3), t4;
              }
              getTracerProvider() {
                return (0, n2.getGlobal)(l) || this._proxyTracerProvider;
              }
              getTracer(e3, t4) {
                return this.getTracerProvider().getTracer(e3, t4);
              }
              disable() {
                (0, n2.unregisterGlobal)(l, s.DiagAPI.instance()), this._proxyTracerProvider = new i2.ProxyTracerProvider();
              }
            }
            t3.TraceAPI = u;
          },
          277: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.deleteBaggage = t3.setBaggage = t3.getActiveBaggage = t3.getBaggage = void 0;
            let n2 = r2(491), i2 = (0, r2(780).createContextKey)("OpenTelemetry Baggage Key");
            function a2(e3) {
              return e3.getValue(i2) || void 0;
            }
            t3.getBaggage = a2, t3.getActiveBaggage = function() {
              return a2(n2.ContextAPI.getInstance().active());
            }, t3.setBaggage = function(e3, t4) {
              return e3.setValue(i2, t4);
            }, t3.deleteBaggage = function(e3) {
              return e3.deleteValue(i2);
            };
          },
          993: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.BaggageImpl = void 0;
            class r2 {
              constructor(e3) {
                this._entries = e3 ? new Map(e3) : /* @__PURE__ */ new Map();
              }
              getEntry(e3) {
                let t4 = this._entries.get(e3);
                if (t4) return Object.assign({}, t4);
              }
              getAllEntries() {
                return Array.from(this._entries.entries()).map(([e3, t4]) => [
                  e3,
                  t4
                ]);
              }
              setEntry(e3, t4) {
                let n2 = new r2(this._entries);
                return n2._entries.set(e3, t4), n2;
              }
              removeEntry(e3) {
                let t4 = new r2(this._entries);
                return t4._entries.delete(e3), t4;
              }
              removeEntries(...e3) {
                let t4 = new r2(this._entries);
                for (let r3 of e3) t4._entries.delete(r3);
                return t4;
              }
              clear() {
                return new r2();
              }
            }
            t3.BaggageImpl = r2;
          },
          830: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.baggageEntryMetadataSymbol = void 0, t3.baggageEntryMetadataSymbol = Symbol("BaggageEntryMetadata");
          },
          369: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.baggageEntryMetadataFromString = t3.createBaggage = void 0;
            let n2 = r2(930), i2 = r2(993), a2 = r2(830), o = n2.DiagAPI.instance();
            t3.createBaggage = function(e3 = {}) {
              return new i2.BaggageImpl(new Map(Object.entries(e3)));
            }, t3.baggageEntryMetadataFromString = function(e3) {
              return "string" != typeof e3 && (o.error(`Cannot create baggage metadata from unknown type: ${typeof e3}`), e3 = ""), {
                __TYPE__: a2.baggageEntryMetadataSymbol,
                toString: () => e3
              };
            };
          },
          67: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.context = void 0;
            let n2 = r2(491);
            t3.context = n2.ContextAPI.getInstance();
          },
          223: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.NoopContextManager = void 0;
            let n2 = r2(780);
            class i2 {
              active() {
                return n2.ROOT_CONTEXT;
              }
              with(e3, t4, r3, ...n3) {
                return t4.call(r3, ...n3);
              }
              bind(e3, t4) {
                return t4;
              }
              enable() {
                return this;
              }
              disable() {
                return this;
              }
            }
            t3.NoopContextManager = i2;
          },
          780: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.ROOT_CONTEXT = t3.createContextKey = void 0, t3.createContextKey = function(e3) {
              return Symbol.for(e3);
            };
            class r2 {
              constructor(e3) {
                let t4 = this;
                t4._currentContext = e3 ? new Map(e3) : /* @__PURE__ */ new Map(), t4.getValue = (e4) => t4._currentContext.get(e4), t4.setValue = (e4, n2) => {
                  let i2 = new r2(t4._currentContext);
                  return i2._currentContext.set(e4, n2), i2;
                }, t4.deleteValue = (e4) => {
                  let n2 = new r2(t4._currentContext);
                  return n2._currentContext.delete(e4), n2;
                };
              }
            }
            t3.ROOT_CONTEXT = new r2();
          },
          506: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.diag = void 0;
            let n2 = r2(930);
            t3.diag = n2.DiagAPI.instance();
          },
          56: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.DiagComponentLogger = void 0;
            let n2 = r2(172);
            class i2 {
              constructor(e3) {
                this._namespace = e3.namespace || "DiagComponentLogger";
              }
              debug(...e3) {
                return a2("debug", this._namespace, e3);
              }
              error(...e3) {
                return a2("error", this._namespace, e3);
              }
              info(...e3) {
                return a2("info", this._namespace, e3);
              }
              warn(...e3) {
                return a2("warn", this._namespace, e3);
              }
              verbose(...e3) {
                return a2("verbose", this._namespace, e3);
              }
            }
            function a2(e3, t4, r3) {
              let i3 = (0, n2.getGlobal)("diag");
              if (i3) return r3.unshift(t4), i3[e3](...r3);
            }
            t3.DiagComponentLogger = i2;
          },
          972: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.DiagConsoleLogger = void 0;
            let r2 = [
              {
                n: "error",
                c: "error"
              },
              {
                n: "warn",
                c: "warn"
              },
              {
                n: "info",
                c: "info"
              },
              {
                n: "debug",
                c: "debug"
              },
              {
                n: "verbose",
                c: "trace"
              }
            ];
            class n2 {
              constructor() {
                for (let e3 = 0; e3 < r2.length; e3++) this[r2[e3].n] = /* @__PURE__ */ function(e4) {
                  return function(...t4) {
                    if (console) {
                      let r3 = console[e4];
                      if ("function" != typeof r3 && (r3 = console.log), "function" == typeof r3) return r3.apply(console, t4);
                    }
                  };
                }(r2[e3].c);
              }
            }
            t3.DiagConsoleLogger = n2;
          },
          912: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.createLogLevelDiagLogger = void 0;
            let n2 = r2(957);
            t3.createLogLevelDiagLogger = function(e3, t4) {
              function r3(r4, n3) {
                let i2 = t4[r4];
                return "function" == typeof i2 && e3 >= n3 ? i2.bind(t4) : function() {
                };
              }
              return e3 < n2.DiagLogLevel.NONE ? e3 = n2.DiagLogLevel.NONE : e3 > n2.DiagLogLevel.ALL && (e3 = n2.DiagLogLevel.ALL), t4 = t4 || {}, {
                error: r3("error", n2.DiagLogLevel.ERROR),
                warn: r3("warn", n2.DiagLogLevel.WARN),
                info: r3("info", n2.DiagLogLevel.INFO),
                debug: r3("debug", n2.DiagLogLevel.DEBUG),
                verbose: r3("verbose", n2.DiagLogLevel.VERBOSE)
              };
            };
          },
          957: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.DiagLogLevel = void 0, function(e3) {
              e3[e3.NONE = 0] = "NONE", e3[e3.ERROR = 30] = "ERROR", e3[e3.WARN = 50] = "WARN", e3[e3.INFO = 60] = "INFO", e3[e3.DEBUG = 70] = "DEBUG", e3[e3.VERBOSE = 80] = "VERBOSE", e3[e3.ALL = 9999] = "ALL";
            }(t3.DiagLogLevel || (t3.DiagLogLevel = {}));
          },
          172: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.unregisterGlobal = t3.getGlobal = t3.registerGlobal = void 0;
            let n2 = r2(200), i2 = r2(521), a2 = r2(130), o = i2.VERSION.split(".")[0], s = Symbol.for(`opentelemetry.js.api.${o}`), l = n2._globalThis;
            t3.registerGlobal = function(e3, t4, r3, n3 = false) {
              var a3;
              let o2 = l[s] = null !== (a3 = l[s]) && void 0 !== a3 ? a3 : {
                version: i2.VERSION
              };
              if (!n3 && o2[e3]) {
                let t5 = Error(`@opentelemetry/api: Attempted duplicate registration of API: ${e3}`);
                return r3.error(t5.stack || t5.message), false;
              }
              if (o2.version !== i2.VERSION) {
                let t5 = Error(`@opentelemetry/api: Registration of version v${o2.version} for ${e3} does not match previously registered API v${i2.VERSION}`);
                return r3.error(t5.stack || t5.message), false;
              }
              return o2[e3] = t4, r3.debug(`@opentelemetry/api: Registered a global for ${e3} v${i2.VERSION}.`), true;
            }, t3.getGlobal = function(e3) {
              var t4, r3;
              let n3 = null === (t4 = l[s]) || void 0 === t4 ? void 0 : t4.version;
              if (n3 && (0, a2.isCompatible)(n3)) return null === (r3 = l[s]) || void 0 === r3 ? void 0 : r3[e3];
            }, t3.unregisterGlobal = function(e3, t4) {
              t4.debug(`@opentelemetry/api: Unregistering a global for ${e3} v${i2.VERSION}.`);
              let r3 = l[s];
              r3 && delete r3[e3];
            };
          },
          130: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.isCompatible = t3._makeCompatibilityCheck = void 0;
            let n2 = r2(521), i2 = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
            function a2(e3) {
              let t4 = /* @__PURE__ */ new Set([
                e3
              ]), r3 = /* @__PURE__ */ new Set(), n3 = e3.match(i2);
              if (!n3) return () => false;
              let a3 = {
                major: +n3[1],
                minor: +n3[2],
                patch: +n3[3],
                prerelease: n3[4]
              };
              if (null != a3.prerelease) return function(t5) {
                return t5 === e3;
              };
              function o(e4) {
                return r3.add(e4), false;
              }
              return function(e4) {
                if (t4.has(e4)) return true;
                if (r3.has(e4)) return false;
                let n4 = e4.match(i2);
                if (!n4) return o(e4);
                let s = {
                  major: +n4[1],
                  minor: +n4[2],
                  patch: +n4[3],
                  prerelease: n4[4]
                };
                return null != s.prerelease || a3.major !== s.major ? o(e4) : 0 === a3.major ? a3.minor === s.minor && a3.patch <= s.patch ? (t4.add(e4), true) : o(e4) : a3.minor <= s.minor ? (t4.add(e4), true) : o(e4);
              };
            }
            t3._makeCompatibilityCheck = a2, t3.isCompatible = a2(n2.VERSION);
          },
          886: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.metrics = void 0;
            let n2 = r2(653);
            t3.metrics = n2.MetricsAPI.getInstance();
          },
          901: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.ValueType = void 0, function(e3) {
              e3[e3.INT = 0] = "INT", e3[e3.DOUBLE = 1] = "DOUBLE";
            }(t3.ValueType || (t3.ValueType = {}));
          },
          102: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.createNoopMeter = t3.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = t3.NOOP_OBSERVABLE_GAUGE_METRIC = t3.NOOP_OBSERVABLE_COUNTER_METRIC = t3.NOOP_UP_DOWN_COUNTER_METRIC = t3.NOOP_HISTOGRAM_METRIC = t3.NOOP_COUNTER_METRIC = t3.NOOP_METER = t3.NoopObservableUpDownCounterMetric = t3.NoopObservableGaugeMetric = t3.NoopObservableCounterMetric = t3.NoopObservableMetric = t3.NoopHistogramMetric = t3.NoopUpDownCounterMetric = t3.NoopCounterMetric = t3.NoopMetric = t3.NoopMeter = void 0;
            class r2 {
              constructor() {
              }
              createHistogram(e3, r3) {
                return t3.NOOP_HISTOGRAM_METRIC;
              }
              createCounter(e3, r3) {
                return t3.NOOP_COUNTER_METRIC;
              }
              createUpDownCounter(e3, r3) {
                return t3.NOOP_UP_DOWN_COUNTER_METRIC;
              }
              createObservableGauge(e3, r3) {
                return t3.NOOP_OBSERVABLE_GAUGE_METRIC;
              }
              createObservableCounter(e3, r3) {
                return t3.NOOP_OBSERVABLE_COUNTER_METRIC;
              }
              createObservableUpDownCounter(e3, r3) {
                return t3.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC;
              }
              addBatchObservableCallback(e3, t4) {
              }
              removeBatchObservableCallback(e3) {
              }
            }
            t3.NoopMeter = r2;
            class n2 {
            }
            t3.NoopMetric = n2;
            class i2 extends n2 {
              add(e3, t4) {
              }
            }
            t3.NoopCounterMetric = i2;
            class a2 extends n2 {
              add(e3, t4) {
              }
            }
            t3.NoopUpDownCounterMetric = a2;
            class o extends n2 {
              record(e3, t4) {
              }
            }
            t3.NoopHistogramMetric = o;
            class s {
              addCallback(e3) {
              }
              removeCallback(e3) {
              }
            }
            t3.NoopObservableMetric = s;
            class l extends s {
            }
            t3.NoopObservableCounterMetric = l;
            class u extends s {
            }
            t3.NoopObservableGaugeMetric = u;
            class d extends s {
            }
            t3.NoopObservableUpDownCounterMetric = d, t3.NOOP_METER = new r2(), t3.NOOP_COUNTER_METRIC = new i2(), t3.NOOP_HISTOGRAM_METRIC = new o(), t3.NOOP_UP_DOWN_COUNTER_METRIC = new a2(), t3.NOOP_OBSERVABLE_COUNTER_METRIC = new l(), t3.NOOP_OBSERVABLE_GAUGE_METRIC = new u(), t3.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = new d(), t3.createNoopMeter = function() {
              return t3.NOOP_METER;
            };
          },
          660: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.NOOP_METER_PROVIDER = t3.NoopMeterProvider = void 0;
            let n2 = r2(102);
            class i2 {
              getMeter(e3, t4, r3) {
                return n2.NOOP_METER;
              }
            }
            t3.NoopMeterProvider = i2, t3.NOOP_METER_PROVIDER = new i2();
          },
          200: function(e2, t3, r2) {
            var n2 = this && this.__createBinding || (Object.create ? function(e3, t4, r3, n3) {
              void 0 === n3 && (n3 = r3), Object.defineProperty(e3, n3, {
                enumerable: true,
                get: function() {
                  return t4[r3];
                }
              });
            } : function(e3, t4, r3, n3) {
              void 0 === n3 && (n3 = r3), e3[n3] = t4[r3];
            }), i2 = this && this.__exportStar || function(e3, t4) {
              for (var r3 in e3) "default" === r3 || Object.prototype.hasOwnProperty.call(t4, r3) || n2(t4, e3, r3);
            };
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), i2(r2(46), t3);
          },
          651: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3._globalThis = void 0, t3._globalThis = "object" == typeof globalThis ? globalThis : r.g;
          },
          46: function(e2, t3, r2) {
            var n2 = this && this.__createBinding || (Object.create ? function(e3, t4, r3, n3) {
              void 0 === n3 && (n3 = r3), Object.defineProperty(e3, n3, {
                enumerable: true,
                get: function() {
                  return t4[r3];
                }
              });
            } : function(e3, t4, r3, n3) {
              void 0 === n3 && (n3 = r3), e3[n3] = t4[r3];
            }), i2 = this && this.__exportStar || function(e3, t4) {
              for (var r3 in e3) "default" === r3 || Object.prototype.hasOwnProperty.call(t4, r3) || n2(t4, e3, r3);
            };
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), i2(r2(651), t3);
          },
          939: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.propagation = void 0;
            let n2 = r2(181);
            t3.propagation = n2.PropagationAPI.getInstance();
          },
          874: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.NoopTextMapPropagator = void 0;
            class r2 {
              inject(e3, t4) {
              }
              extract(e3, t4) {
                return e3;
              }
              fields() {
                return [];
              }
            }
            t3.NoopTextMapPropagator = r2;
          },
          194: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.defaultTextMapSetter = t3.defaultTextMapGetter = void 0, t3.defaultTextMapGetter = {
              get(e3, t4) {
                if (null != e3) return e3[t4];
              },
              keys: (e3) => null == e3 ? [] : Object.keys(e3)
            }, t3.defaultTextMapSetter = {
              set(e3, t4, r2) {
                null != e3 && (e3[t4] = r2);
              }
            };
          },
          845: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.trace = void 0;
            let n2 = r2(997);
            t3.trace = n2.TraceAPI.getInstance();
          },
          403: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.NonRecordingSpan = void 0;
            let n2 = r2(476);
            class i2 {
              constructor(e3 = n2.INVALID_SPAN_CONTEXT) {
                this._spanContext = e3;
              }
              spanContext() {
                return this._spanContext;
              }
              setAttribute(e3, t4) {
                return this;
              }
              setAttributes(e3) {
                return this;
              }
              addEvent(e3, t4) {
                return this;
              }
              setStatus(e3) {
                return this;
              }
              updateName(e3) {
                return this;
              }
              end(e3) {
              }
              isRecording() {
                return false;
              }
              recordException(e3, t4) {
              }
            }
            t3.NonRecordingSpan = i2;
          },
          614: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.NoopTracer = void 0;
            let n2 = r2(491), i2 = r2(607), a2 = r2(403), o = r2(139), s = n2.ContextAPI.getInstance();
            class l {
              startSpan(e3, t4, r3 = s.active()) {
                if (null == t4 ? void 0 : t4.root) return new a2.NonRecordingSpan();
                let n3 = r3 && (0, i2.getSpanContext)(r3);
                return "object" == typeof n3 && "string" == typeof n3.spanId && "string" == typeof n3.traceId && "number" == typeof n3.traceFlags && (0, o.isSpanContextValid)(n3) ? new a2.NonRecordingSpan(n3) : new a2.NonRecordingSpan();
              }
              startActiveSpan(e3, t4, r3, n3) {
                let a3, o2, l2;
                if (arguments.length < 2) return;
                2 == arguments.length ? l2 = t4 : 3 == arguments.length ? (a3 = t4, l2 = r3) : (a3 = t4, o2 = r3, l2 = n3);
                let u = null != o2 ? o2 : s.active(), d = this.startSpan(e3, a3, u), c = (0, i2.setSpan)(u, d);
                return s.with(c, l2, void 0, d);
              }
            }
            t3.NoopTracer = l;
          },
          124: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.NoopTracerProvider = void 0;
            let n2 = r2(614);
            class i2 {
              getTracer(e3, t4, r3) {
                return new n2.NoopTracer();
              }
            }
            t3.NoopTracerProvider = i2;
          },
          125: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.ProxyTracer = void 0;
            let n2 = new (r2(614)).NoopTracer();
            class i2 {
              constructor(e3, t4, r3, n3) {
                this._provider = e3, this.name = t4, this.version = r3, this.options = n3;
              }
              startSpan(e3, t4, r3) {
                return this._getTracer().startSpan(e3, t4, r3);
              }
              startActiveSpan(e3, t4, r3, n3) {
                let i3 = this._getTracer();
                return Reflect.apply(i3.startActiveSpan, i3, arguments);
              }
              _getTracer() {
                if (this._delegate) return this._delegate;
                let e3 = this._provider.getDelegateTracer(this.name, this.version, this.options);
                return e3 ? (this._delegate = e3, this._delegate) : n2;
              }
            }
            t3.ProxyTracer = i2;
          },
          846: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.ProxyTracerProvider = void 0;
            let n2 = r2(125), i2 = new (r2(124)).NoopTracerProvider();
            class a2 {
              getTracer(e3, t4, r3) {
                var i3;
                return null !== (i3 = this.getDelegateTracer(e3, t4, r3)) && void 0 !== i3 ? i3 : new n2.ProxyTracer(this, e3, t4, r3);
              }
              getDelegate() {
                var e3;
                return null !== (e3 = this._delegate) && void 0 !== e3 ? e3 : i2;
              }
              setDelegate(e3) {
                this._delegate = e3;
              }
              getDelegateTracer(e3, t4, r3) {
                var n3;
                return null === (n3 = this._delegate) || void 0 === n3 ? void 0 : n3.getTracer(e3, t4, r3);
              }
            }
            t3.ProxyTracerProvider = a2;
          },
          996: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.SamplingDecision = void 0, function(e3) {
              e3[e3.NOT_RECORD = 0] = "NOT_RECORD", e3[e3.RECORD = 1] = "RECORD", e3[e3.RECORD_AND_SAMPLED = 2] = "RECORD_AND_SAMPLED";
            }(t3.SamplingDecision || (t3.SamplingDecision = {}));
          },
          607: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.getSpanContext = t3.setSpanContext = t3.deleteSpan = t3.setSpan = t3.getActiveSpan = t3.getSpan = void 0;
            let n2 = r2(780), i2 = r2(403), a2 = r2(491), o = (0, n2.createContextKey)("OpenTelemetry Context Key SPAN");
            function s(e3) {
              return e3.getValue(o) || void 0;
            }
            function l(e3, t4) {
              return e3.setValue(o, t4);
            }
            t3.getSpan = s, t3.getActiveSpan = function() {
              return s(a2.ContextAPI.getInstance().active());
            }, t3.setSpan = l, t3.deleteSpan = function(e3) {
              return e3.deleteValue(o);
            }, t3.setSpanContext = function(e3, t4) {
              return l(e3, new i2.NonRecordingSpan(t4));
            }, t3.getSpanContext = function(e3) {
              var t4;
              return null === (t4 = s(e3)) || void 0 === t4 ? void 0 : t4.spanContext();
            };
          },
          325: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.TraceStateImpl = void 0;
            let n2 = r2(564);
            class i2 {
              constructor(e3) {
                this._internalState = /* @__PURE__ */ new Map(), e3 && this._parse(e3);
              }
              set(e3, t4) {
                let r3 = this._clone();
                return r3._internalState.has(e3) && r3._internalState.delete(e3), r3._internalState.set(e3, t4), r3;
              }
              unset(e3) {
                let t4 = this._clone();
                return t4._internalState.delete(e3), t4;
              }
              get(e3) {
                return this._internalState.get(e3);
              }
              serialize() {
                return this._keys().reduce((e3, t4) => (e3.push(t4 + "=" + this.get(t4)), e3), []).join(",");
              }
              _parse(e3) {
                !(e3.length > 512) && (this._internalState = e3.split(",").reverse().reduce((e4, t4) => {
                  let r3 = t4.trim(), i3 = r3.indexOf("=");
                  if (-1 !== i3) {
                    let a2 = r3.slice(0, i3), o = r3.slice(i3 + 1, t4.length);
                    (0, n2.validateKey)(a2) && (0, n2.validateValue)(o) && e4.set(a2, o);
                  }
                  return e4;
                }, /* @__PURE__ */ new Map()), this._internalState.size > 32 && (this._internalState = new Map(Array.from(this._internalState.entries()).reverse().slice(0, 32))));
              }
              _keys() {
                return Array.from(this._internalState.keys()).reverse();
              }
              _clone() {
                let e3 = new i2();
                return e3._internalState = new Map(this._internalState), e3;
              }
            }
            t3.TraceStateImpl = i2;
          },
          564: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.validateValue = t3.validateKey = void 0;
            let r2 = "[_0-9a-z-*/]", n2 = `[a-z]${r2}{0,255}`, i2 = `[a-z0-9]${r2}{0,240}@[a-z]${r2}{0,13}`, a2 = RegExp(`^(?:${n2}|${i2})$`), o = /^[ -~]{0,255}[!-~]$/, s = /,|=/;
            t3.validateKey = function(e3) {
              return a2.test(e3);
            }, t3.validateValue = function(e3) {
              return o.test(e3) && !s.test(e3);
            };
          },
          98: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.createTraceState = void 0;
            let n2 = r2(325);
            t3.createTraceState = function(e3) {
              return new n2.TraceStateImpl(e3);
            };
          },
          476: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.INVALID_SPAN_CONTEXT = t3.INVALID_TRACEID = t3.INVALID_SPANID = void 0;
            let n2 = r2(475);
            t3.INVALID_SPANID = "0000000000000000", t3.INVALID_TRACEID = "00000000000000000000000000000000", t3.INVALID_SPAN_CONTEXT = {
              traceId: t3.INVALID_TRACEID,
              spanId: t3.INVALID_SPANID,
              traceFlags: n2.TraceFlags.NONE
            };
          },
          357: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.SpanKind = void 0, function(e3) {
              e3[e3.INTERNAL = 0] = "INTERNAL", e3[e3.SERVER = 1] = "SERVER", e3[e3.CLIENT = 2] = "CLIENT", e3[e3.PRODUCER = 3] = "PRODUCER", e3[e3.CONSUMER = 4] = "CONSUMER";
            }(t3.SpanKind || (t3.SpanKind = {}));
          },
          139: (e2, t3, r2) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.wrapSpanContext = t3.isSpanContextValid = t3.isValidSpanId = t3.isValidTraceId = void 0;
            let n2 = r2(476), i2 = r2(403), a2 = /^([0-9a-f]{32})$/i, o = /^[0-9a-f]{16}$/i;
            function s(e3) {
              return a2.test(e3) && e3 !== n2.INVALID_TRACEID;
            }
            function l(e3) {
              return o.test(e3) && e3 !== n2.INVALID_SPANID;
            }
            t3.isValidTraceId = s, t3.isValidSpanId = l, t3.isSpanContextValid = function(e3) {
              return s(e3.traceId) && l(e3.spanId);
            }, t3.wrapSpanContext = function(e3) {
              return new i2.NonRecordingSpan(e3);
            };
          },
          847: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.SpanStatusCode = void 0, function(e3) {
              e3[e3.UNSET = 0] = "UNSET", e3[e3.OK = 1] = "OK", e3[e3.ERROR = 2] = "ERROR";
            }(t3.SpanStatusCode || (t3.SpanStatusCode = {}));
          },
          475: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.TraceFlags = void 0, function(e3) {
              e3[e3.NONE = 0] = "NONE", e3[e3.SAMPLED = 1] = "SAMPLED";
            }(t3.TraceFlags || (t3.TraceFlags = {}));
          },
          521: (e2, t3) => {
            Object.defineProperty(t3, "__esModule", {
              value: true
            }), t3.VERSION = void 0, t3.VERSION = "1.6.0";
          }
        }, n = {};
        function i(e2) {
          var r2 = n[e2];
          if (void 0 !== r2) return r2.exports;
          var a2 = n[e2] = {
            exports: {}
          }, o = true;
          try {
            t2[e2].call(a2.exports, a2, a2.exports, i), o = false;
          } finally {
            o && delete n[e2];
          }
          return a2.exports;
        }
        i.ab = "//";
        var a = {};
        (() => {
          Object.defineProperty(a, "__esModule", {
            value: true
          }), a.trace = a.propagation = a.metrics = a.diag = a.context = a.INVALID_SPAN_CONTEXT = a.INVALID_TRACEID = a.INVALID_SPANID = a.isValidSpanId = a.isValidTraceId = a.isSpanContextValid = a.createTraceState = a.TraceFlags = a.SpanStatusCode = a.SpanKind = a.SamplingDecision = a.ProxyTracerProvider = a.ProxyTracer = a.defaultTextMapSetter = a.defaultTextMapGetter = a.ValueType = a.createNoopMeter = a.DiagLogLevel = a.DiagConsoleLogger = a.ROOT_CONTEXT = a.createContextKey = a.baggageEntryMetadataFromString = void 0;
          var e2 = i(369);
          Object.defineProperty(a, "baggageEntryMetadataFromString", {
            enumerable: true,
            get: function() {
              return e2.baggageEntryMetadataFromString;
            }
          });
          var t3 = i(780);
          Object.defineProperty(a, "createContextKey", {
            enumerable: true,
            get: function() {
              return t3.createContextKey;
            }
          }), Object.defineProperty(a, "ROOT_CONTEXT", {
            enumerable: true,
            get: function() {
              return t3.ROOT_CONTEXT;
            }
          });
          var r2 = i(972);
          Object.defineProperty(a, "DiagConsoleLogger", {
            enumerable: true,
            get: function() {
              return r2.DiagConsoleLogger;
            }
          });
          var n2 = i(957);
          Object.defineProperty(a, "DiagLogLevel", {
            enumerable: true,
            get: function() {
              return n2.DiagLogLevel;
            }
          });
          var o = i(102);
          Object.defineProperty(a, "createNoopMeter", {
            enumerable: true,
            get: function() {
              return o.createNoopMeter;
            }
          });
          var s = i(901);
          Object.defineProperty(a, "ValueType", {
            enumerable: true,
            get: function() {
              return s.ValueType;
            }
          });
          var l = i(194);
          Object.defineProperty(a, "defaultTextMapGetter", {
            enumerable: true,
            get: function() {
              return l.defaultTextMapGetter;
            }
          }), Object.defineProperty(a, "defaultTextMapSetter", {
            enumerable: true,
            get: function() {
              return l.defaultTextMapSetter;
            }
          });
          var u = i(125);
          Object.defineProperty(a, "ProxyTracer", {
            enumerable: true,
            get: function() {
              return u.ProxyTracer;
            }
          });
          var d = i(846);
          Object.defineProperty(a, "ProxyTracerProvider", {
            enumerable: true,
            get: function() {
              return d.ProxyTracerProvider;
            }
          });
          var c = i(996);
          Object.defineProperty(a, "SamplingDecision", {
            enumerable: true,
            get: function() {
              return c.SamplingDecision;
            }
          });
          var p = i(357);
          Object.defineProperty(a, "SpanKind", {
            enumerable: true,
            get: function() {
              return p.SpanKind;
            }
          });
          var g = i(847);
          Object.defineProperty(a, "SpanStatusCode", {
            enumerable: true,
            get: function() {
              return g.SpanStatusCode;
            }
          });
          var h = i(475);
          Object.defineProperty(a, "TraceFlags", {
            enumerable: true,
            get: function() {
              return h.TraceFlags;
            }
          });
          var f = i(98);
          Object.defineProperty(a, "createTraceState", {
            enumerable: true,
            get: function() {
              return f.createTraceState;
            }
          });
          var b = i(139);
          Object.defineProperty(a, "isSpanContextValid", {
            enumerable: true,
            get: function() {
              return b.isSpanContextValid;
            }
          }), Object.defineProperty(a, "isValidTraceId", {
            enumerable: true,
            get: function() {
              return b.isValidTraceId;
            }
          }), Object.defineProperty(a, "isValidSpanId", {
            enumerable: true,
            get: function() {
              return b.isValidSpanId;
            }
          });
          var m = i(476);
          Object.defineProperty(a, "INVALID_SPANID", {
            enumerable: true,
            get: function() {
              return m.INVALID_SPANID;
            }
          }), Object.defineProperty(a, "INVALID_TRACEID", {
            enumerable: true,
            get: function() {
              return m.INVALID_TRACEID;
            }
          }), Object.defineProperty(a, "INVALID_SPAN_CONTEXT", {
            enumerable: true,
            get: function() {
              return m.INVALID_SPAN_CONTEXT;
            }
          });
          let v = i(67);
          Object.defineProperty(a, "context", {
            enumerable: true,
            get: function() {
              return v.context;
            }
          });
          let w = i(506);
          Object.defineProperty(a, "diag", {
            enumerable: true,
            get: function() {
              return w.diag;
            }
          });
          let y = i(886);
          Object.defineProperty(a, "metrics", {
            enumerable: true,
            get: function() {
              return y.metrics;
            }
          });
          let _ = i(939);
          Object.defineProperty(a, "propagation", {
            enumerable: true,
            get: function() {
              return _.propagation;
            }
          });
          let x = i(845);
          Object.defineProperty(a, "trace", {
            enumerable: true,
            get: function() {
              return x.trace;
            }
          }), a.default = {
            context: v.context,
            diag: w.diag,
            metrics: y.metrics,
            propagation: _.propagation,
            trace: x.trace
          };
        })(), e.exports = a;
      })();
    },
    373: (e) => {
      (() => {
        "use strict";
        "undefined" != typeof __nccwpck_require__ && (__nccwpck_require__.ab = "//");
        var t = {};
        (() => {
          t.parse = function(t2, r2) {
            if ("string" != typeof t2) throw TypeError("argument str must be a string");
            for (var i2 = {}, a = t2.split(n), o = (r2 || {}).decode || e2, s = 0; s < a.length; s++) {
              var l = a[s], u = l.indexOf("=");
              if (!(u < 0)) {
                var d = l.substr(0, u).trim(), c = l.substr(++u, l.length).trim();
                '"' == c[0] && (c = c.slice(1, -1)), void 0 == i2[d] && (i2[d] = function(e3, t3) {
                  try {
                    return t3(e3);
                  } catch (t4) {
                    return e3;
                  }
                }(c, o));
              }
            }
            return i2;
          }, t.serialize = function(e3, t2, n2) {
            var a = n2 || {}, o = a.encode || r;
            if ("function" != typeof o) throw TypeError("option encode is invalid");
            if (!i.test(e3)) throw TypeError("argument name is invalid");
            var s = o(t2);
            if (s && !i.test(s)) throw TypeError("argument val is invalid");
            var l = e3 + "=" + s;
            if (null != a.maxAge) {
              var u = a.maxAge - 0;
              if (isNaN(u) || !isFinite(u)) throw TypeError("option maxAge is invalid");
              l += "; Max-Age=" + Math.floor(u);
            }
            if (a.domain) {
              if (!i.test(a.domain)) throw TypeError("option domain is invalid");
              l += "; Domain=" + a.domain;
            }
            if (a.path) {
              if (!i.test(a.path)) throw TypeError("option path is invalid");
              l += "; Path=" + a.path;
            }
            if (a.expires) {
              if ("function" != typeof a.expires.toUTCString) throw TypeError("option expires is invalid");
              l += "; Expires=" + a.expires.toUTCString();
            }
            if (a.httpOnly && (l += "; HttpOnly"), a.secure && (l += "; Secure"), a.sameSite) switch ("string" == typeof a.sameSite ? a.sameSite.toLowerCase() : a.sameSite) {
              case true:
              case "strict":
                l += "; SameSite=Strict";
                break;
              case "lax":
                l += "; SameSite=Lax";
                break;
              case "none":
                l += "; SameSite=None";
                break;
              default:
                throw TypeError("option sameSite is invalid");
            }
            return l;
          };
          var e2 = decodeURIComponent, r = encodeURIComponent, n = /; */, i = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;
        })(), e.exports = t;
      })();
    },
    568: (e, t, r) => {
      var n;
      (() => {
        var i = {
          226: function(i2, a2) {
            !function(o2, s2) {
              "use strict";
              var l = "function", u = "undefined", d = "object", c = "string", p = "major", g = "model", h = "name", f = "type", b = "vendor", m = "version", v = "architecture", w = "console", y = "mobile", _ = "tablet", x = "smarttv", S = "wearable", P = "embedded", O = "Amazon", N = "Apple", R = "ASUS", T = "BlackBerry", C = "Browser", E = "Chrome", M = "Firefox", I = "Google", A = "Huawei", L = "Microsoft", k = "Motorola", j = "Opera", D = "Samsung", V = "Sharp", B = "Sony", U = "Xiaomi", q = "Zebra", $ = "Facebook", G = "Chromium OS", H = "Mac OS", F = function(e2, t2) {
                var r2 = {};
                for (var n2 in e2) t2[n2] && t2[n2].length % 2 == 0 ? r2[n2] = t2[n2].concat(e2[n2]) : r2[n2] = e2[n2];
                return r2;
              }, z = function(e2) {
                for (var t2 = {}, r2 = 0; r2 < e2.length; r2++) t2[e2[r2].toUpperCase()] = e2[r2];
                return t2;
              }, W = function(e2, t2) {
                return typeof e2 === c && -1 !== K(t2).indexOf(K(e2));
              }, K = function(e2) {
                return e2.toLowerCase();
              }, X = function(e2, t2) {
                if (typeof e2 === c) return e2 = e2.replace(/^\s\s*/, ""), typeof t2 === u ? e2 : e2.substring(0, 350);
              }, Z = function(e2, t2) {
                for (var r2, n2, i3, a3, o3, u2, c2 = 0; c2 < t2.length && !o3; ) {
                  var p2 = t2[c2], g2 = t2[c2 + 1];
                  for (r2 = n2 = 0; r2 < p2.length && !o3 && p2[r2]; ) if (o3 = p2[r2++].exec(e2)) for (i3 = 0; i3 < g2.length; i3++) u2 = o3[++n2], typeof (a3 = g2[i3]) === d && a3.length > 0 ? 2 === a3.length ? typeof a3[1] == l ? this[a3[0]] = a3[1].call(this, u2) : this[a3[0]] = a3[1] : 3 === a3.length ? typeof a3[1] !== l || a3[1].exec && a3[1].test ? this[a3[0]] = u2 ? u2.replace(a3[1], a3[2]) : void 0 : this[a3[0]] = u2 ? a3[1].call(this, u2, a3[2]) : void 0 : 4 === a3.length && (this[a3[0]] = u2 ? a3[3].call(this, u2.replace(a3[1], a3[2])) : void 0) : this[a3] = u2 || s2;
                  c2 += 2;
                }
              }, J = function(e2, t2) {
                for (var r2 in t2) if (typeof t2[r2] === d && t2[r2].length > 0) {
                  for (var n2 = 0; n2 < t2[r2].length; n2++) if (W(t2[r2][n2], e2)) return "?" === r2 ? s2 : r2;
                } else if (W(t2[r2], e2)) return "?" === r2 ? s2 : r2;
                return e2;
              }, Y = {
                ME: "4.90",
                "NT 3.11": "NT3.51",
                "NT 4.0": "NT4.0",
                2e3: "NT 5.0",
                XP: [
                  "NT 5.1",
                  "NT 5.2"
                ],
                Vista: "NT 6.0",
                7: "NT 6.1",
                8: "NT 6.2",
                8.1: "NT 6.3",
                10: [
                  "NT 6.4",
                  "NT 10.0"
                ],
                RT: "ARM"
              }, Q = {
                browser: [
                  [
                    /\b(?:crmo|crios)\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "Chrome"
                    ]
                  ],
                  [
                    /edg(?:e|ios|a)?\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "Edge"
                    ]
                  ],
                  [
                    /(opera mini)\/([-\w\.]+)/i,
                    /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i,
                    /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /opios[\/ ]+([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      j + " Mini"
                    ]
                  ],
                  [
                    /\bopr\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      j
                    ]
                  ],
                  [
                    /(kindle)\/([\w\.]+)/i,
                    /(lunascape|maxthon|netfront|jasmine|blazer)[\/ ]?([\w\.]*)/i,
                    /(avant |iemobile|slim)(?:browser)?[\/ ]?([\w\.]*)/i,
                    /(ba?idubrowser)[\/ ]?([\w\.]+)/i,
                    /(?:ms|\()(ie) ([\w\.]+)/i,
                    /(flock|rockmelt|midori|epiphany|silk|skyfire|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|qq|duckduckgo)\/([-\w\.]+)/i,
                    /(heytap|ovi)browser\/([\d\.]+)/i,
                    /(weibo)__([\d\.]+)/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "UC" + C
                    ]
                  ],
                  [
                    /microm.+\bqbcore\/([\w\.]+)/i,
                    /\bqbcore\/([\w\.]+).+microm/i
                  ],
                  [
                    m,
                    [
                      h,
                      "WeChat(Win) Desktop"
                    ]
                  ],
                  [
                    /micromessenger\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "WeChat"
                    ]
                  ],
                  [
                    /konqueror\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "Konqueror"
                    ]
                  ],
                  [
                    /trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i
                  ],
                  [
                    m,
                    [
                      h,
                      "IE"
                    ]
                  ],
                  [
                    /ya(?:search)?browser\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "Yandex"
                    ]
                  ],
                  [
                    /(avast|avg)\/([\w\.]+)/i
                  ],
                  [
                    [
                      h,
                      /(.+)/,
                      "$1 Secure " + C
                    ],
                    m
                  ],
                  [
                    /\bfocus\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      M + " Focus"
                    ]
                  ],
                  [
                    /\bopt\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      j + " Touch"
                    ]
                  ],
                  [
                    /coc_coc\w+\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "Coc Coc"
                    ]
                  ],
                  [
                    /dolfin\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "Dolphin"
                    ]
                  ],
                  [
                    /coast\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      j + " Coast"
                    ]
                  ],
                  [
                    /miuibrowser\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "MIUI " + C
                    ]
                  ],
                  [
                    /fxios\/([-\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      M
                    ]
                  ],
                  [
                    /\bqihu|(qi?ho?o?|360)browser/i
                  ],
                  [
                    [
                      h,
                      "360 " + C
                    ]
                  ],
                  [
                    /(oculus|samsung|sailfish|huawei)browser\/([\w\.]+)/i
                  ],
                  [
                    [
                      h,
                      /(.+)/,
                      "$1 " + C
                    ],
                    m
                  ],
                  [
                    /(comodo_dragon)\/([\w\.]+)/i
                  ],
                  [
                    [
                      h,
                      /_/g,
                      " "
                    ],
                    m
                  ],
                  [
                    /(electron)\/([\w\.]+) safari/i,
                    /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i,
                    /m?(qqbrowser|baiduboxapp|2345Explorer)[\/ ]?([\w\.]+)/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /(metasr)[\/ ]?([\w\.]+)/i,
                    /(lbbrowser)/i,
                    /\[(linkedin)app\]/i
                  ],
                  [
                    h
                  ],
                  [
                    /((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i
                  ],
                  [
                    [
                      h,
                      $
                    ],
                    m
                  ],
                  [
                    /(kakao(?:talk|story))[\/ ]([\w\.]+)/i,
                    /(naver)\(.*?(\d+\.[\w\.]+).*\)/i,
                    /safari (line)\/([\w\.]+)/i,
                    /\b(line)\/([\w\.]+)\/iab/i,
                    /(chromium|instagram)[\/ ]([-\w\.]+)/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /\bgsa\/([\w\.]+) .*safari\//i
                  ],
                  [
                    m,
                    [
                      h,
                      "GSA"
                    ]
                  ],
                  [
                    /musical_ly(?:.+app_?version\/|_)([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "TikTok"
                    ]
                  ],
                  [
                    /headlesschrome(?:\/([\w\.]+)| )/i
                  ],
                  [
                    m,
                    [
                      h,
                      E + " Headless"
                    ]
                  ],
                  [
                    / wv\).+(chrome)\/([\w\.]+)/i
                  ],
                  [
                    [
                      h,
                      E + " WebView"
                    ],
                    m
                  ],
                  [
                    /droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "Android " + C
                    ]
                  ],
                  [
                    /(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "Mobile Safari"
                    ]
                  ],
                  [
                    /version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i
                  ],
                  [
                    m,
                    h
                  ],
                  [
                    /webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i
                  ],
                  [
                    h,
                    [
                      m,
                      J,
                      {
                        "1.0": "/8",
                        1.2: "/1",
                        1.3: "/3",
                        "2.0": "/412",
                        "2.0.2": "/416",
                        "2.0.3": "/417",
                        "2.0.4": "/419",
                        "?": "/"
                      }
                    ]
                  ],
                  [
                    /(webkit|khtml)\/([\w\.]+)/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /(navigator|netscape\d?)\/([-\w\.]+)/i
                  ],
                  [
                    [
                      h,
                      "Netscape"
                    ],
                    m
                  ],
                  [
                    /mobile vr; rv:([\w\.]+)\).+firefox/i
                  ],
                  [
                    m,
                    [
                      h,
                      M + " Reality"
                    ]
                  ],
                  [
                    /ekiohf.+(flow)\/([\w\.]+)/i,
                    /(swiftfox)/i,
                    /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i,
                    /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i,
                    /(firefox)\/([\w\.]+)/i,
                    /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i,
                    /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i,
                    /(links) \(([\w\.]+)/i,
                    /panasonic;(viera)/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /(cobalt)\/([\w\.]+)/i
                  ],
                  [
                    h,
                    [
                      m,
                      /master.|lts./,
                      ""
                    ]
                  ]
                ],
                cpu: [
                  [
                    /(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i
                  ],
                  [
                    [
                      v,
                      "amd64"
                    ]
                  ],
                  [
                    /(ia32(?=;))/i
                  ],
                  [
                    [
                      v,
                      K
                    ]
                  ],
                  [
                    /((?:i[346]|x)86)[;\)]/i
                  ],
                  [
                    [
                      v,
                      "ia32"
                    ]
                  ],
                  [
                    /\b(aarch64|arm(v?8e?l?|_?64))\b/i
                  ],
                  [
                    [
                      v,
                      "arm64"
                    ]
                  ],
                  [
                    /\b(arm(?:v[67])?ht?n?[fl]p?)\b/i
                  ],
                  [
                    [
                      v,
                      "armhf"
                    ]
                  ],
                  [
                    /windows (ce|mobile); ppc;/i
                  ],
                  [
                    [
                      v,
                      "arm"
                    ]
                  ],
                  [
                    /((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i
                  ],
                  [
                    [
                      v,
                      /ower/,
                      "",
                      K
                    ]
                  ],
                  [
                    /(sun4\w)[;\)]/i
                  ],
                  [
                    [
                      v,
                      "sparc"
                    ]
                  ],
                  [
                    /((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i
                  ],
                  [
                    [
                      v,
                      K
                    ]
                  ]
                ],
                device: [
                  [
                    /\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i
                  ],
                  [
                    g,
                    [
                      b,
                      D
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b((?:s[cgp]h|gt|sm)-\w+|sc[g-]?[\d]+a?|galaxy nexus)/i,
                    /samsung[- ]([-\w]+)/i,
                    /sec-(sgh\w+)/i
                  ],
                  [
                    g,
                    [
                      b,
                      D
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i
                  ],
                  [
                    g,
                    [
                      b,
                      N
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\((ipad);[-\w\),; ]+apple/i,
                    /applecoremedia\/[\w\.]+ \((ipad)/i,
                    /\b(ipad)\d\d?,\d\d?[;\]].+ios/i
                  ],
                  [
                    g,
                    [
                      b,
                      N
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /(macintosh);/i
                  ],
                  [
                    g,
                    [
                      b,
                      N
                    ]
                  ],
                  [
                    /\b(sh-?[altvz]?\d\d[a-ekm]?)/i
                  ],
                  [
                    g,
                    [
                      b,
                      V
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i
                  ],
                  [
                    g,
                    [
                      b,
                      A
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /(?:huawei|honor)([-\w ]+)[;\)]/i,
                    /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i
                  ],
                  [
                    g,
                    [
                      b,
                      A
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(poco[\w ]+)(?: bui|\))/i,
                    /\b; (\w+) build\/hm\1/i,
                    /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i,
                    /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i,
                    /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite)?)(?: bui|\))/i
                  ],
                  [
                    [
                      g,
                      /_/g,
                      " "
                    ],
                    [
                      b,
                      U
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i
                  ],
                  [
                    [
                      g,
                      /_/g,
                      " "
                    ],
                    [
                      b,
                      U
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /; (\w+) bui.+ oppo/i,
                    /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "OPPO"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /vivo (\w+)(?: bui|\))/i,
                    /\b(v[12]\d{3}\w?[at])(?: bui|;)/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Vivo"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(rmx[12]\d{3})(?: bui|;|\))/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Realme"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i,
                    /\bmot(?:orola)?[- ](\w*)/i,
                    /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i
                  ],
                  [
                    g,
                    [
                      b,
                      k
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(mz60\d|xoom[2 ]{0,2}) build\//i
                  ],
                  [
                    g,
                    [
                      b,
                      k
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i
                  ],
                  [
                    g,
                    [
                      b,
                      "LG"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i,
                    /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i,
                    /\blg-?([\d\w]+) bui/i
                  ],
                  [
                    g,
                    [
                      b,
                      "LG"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(ideatab[-\w ]+)/i,
                    /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Lenovo"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /(?:maemo|nokia).*(n900|lumia \d+)/i,
                    /nokia[-_ ]?([-\w\.]*)/i
                  ],
                  [
                    [
                      g,
                      /_/g,
                      " "
                    ],
                    [
                      b,
                      "Nokia"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(pixel c)\b/i
                  ],
                  [
                    g,
                    [
                      b,
                      I
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i
                  ],
                  [
                    g,
                    [
                      b,
                      I
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /droid.+ (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i
                  ],
                  [
                    g,
                    [
                      b,
                      B
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /sony tablet [ps]/i,
                    /\b(?:sony)?sgp\w+(?: bui|\))/i
                  ],
                  [
                    [
                      g,
                      "Xperia Tablet"
                    ],
                    [
                      b,
                      B
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    / (kb2005|in20[12]5|be20[12][59])\b/i,
                    /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i
                  ],
                  [
                    g,
                    [
                      b,
                      "OnePlus"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(alexa)webm/i,
                    /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i,
                    /(kf[a-z]+)( bui|\)).+silk\//i
                  ],
                  [
                    g,
                    [
                      b,
                      O
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i
                  ],
                  [
                    [
                      g,
                      /(.+)/g,
                      "Fire Phone $1"
                    ],
                    [
                      b,
                      O
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(playbook);[-\w\),; ]+(rim)/i
                  ],
                  [
                    g,
                    b,
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b((?:bb[a-f]|st[hv])100-\d)/i,
                    /\(bb10; (\w+)/i
                  ],
                  [
                    g,
                    [
                      b,
                      T
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i
                  ],
                  [
                    g,
                    [
                      b,
                      R
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    / (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i
                  ],
                  [
                    g,
                    [
                      b,
                      R
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(nexus 9)/i
                  ],
                  [
                    g,
                    [
                      b,
                      "HTC"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i,
                    /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i,
                    /(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i
                  ],
                  [
                    b,
                    [
                      g,
                      /_/g,
                      " "
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /droid.+; ([ab][1-7]-?[0178a]\d\d?)/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Acer"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /droid.+; (m[1-5] note) bui/i,
                    /\bmz-([-\w]{2,})/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Meizu"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron)[-_ ]?([-\w]*)/i,
                    /(hp) ([\w ]+\w)/i,
                    /(asus)-?(\w+)/i,
                    /(microsoft); (lumia[\w ]+)/i,
                    /(lenovo)[-_ ]?([-\w]+)/i,
                    /(jolla)/i,
                    /(oppo) ?([\w ]+) bui/i
                  ],
                  [
                    b,
                    g,
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(kobo)\s(ereader|touch)/i,
                    /(archos) (gamepad2?)/i,
                    /(hp).+(touchpad(?!.+tablet)|tablet)/i,
                    /(kindle)\/([\w\.]+)/i,
                    /(nook)[\w ]+build\/(\w+)/i,
                    /(dell) (strea[kpr\d ]*[\dko])/i,
                    /(le[- ]+pan)[- ]+(\w{1,9}) bui/i,
                    /(trinity)[- ]*(t\d{3}) bui/i,
                    /(gigaset)[- ]+(q\w{1,9}) bui/i,
                    /(vodafone) ([\w ]+)(?:\)| bui)/i
                  ],
                  [
                    b,
                    g,
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /(surface duo)/i
                  ],
                  [
                    g,
                    [
                      b,
                      L
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /droid [\d\.]+; (fp\du?)(?: b|\))/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Fairphone"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(u304aa)/i
                  ],
                  [
                    g,
                    [
                      b,
                      "AT&T"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\bsie-(\w*)/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Siemens"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(rct\w+) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "RCA"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b(venue[\d ]{2,7}) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Dell"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b(q(?:mv|ta)\w+) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Verizon"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Barnes & Noble"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b(tm\d{3}\w+) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "NuVision"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b(k88) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "ZTE"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b(nx\d{3}j) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "ZTE"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(gen\d{3}) b.+49h/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Swiss"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(zur\d{3}) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Swiss"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b((zeki)?tb.*\b) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Zeki"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b([yr]\d{2}) b/i,
                    /\b(dragon[- ]+touch |dt)(\w{5}) b/i
                  ],
                  [
                    [
                      b,
                      "Dragon Touch"
                    ],
                    g,
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b(ns-?\w{0,9}) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Insignia"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b((nxa|next)-?\w{0,9}) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "NextBook"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i
                  ],
                  [
                    [
                      b,
                      "Voice"
                    ],
                    g,
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(lvtel\-)?(v1[12]) b/i
                  ],
                  [
                    [
                      b,
                      "LvTel"
                    ],
                    g,
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(ph-1) /i
                  ],
                  [
                    g,
                    [
                      b,
                      "Essential"
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /\b(v(100md|700na|7011|917g).*\b) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Envizen"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b(trio[-\w\. ]+) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "MachSpeed"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\btu_(1491) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Rotor"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /(shield[\w ]+) b/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Nvidia"
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /(sprint) (\w+)/i
                  ],
                  [
                    b,
                    g,
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(kin\.[onetw]{3})/i
                  ],
                  [
                    [
                      g,
                      /\./g,
                      " "
                    ],
                    [
                      b,
                      L
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i
                  ],
                  [
                    g,
                    [
                      b,
                      q
                    ],
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i
                  ],
                  [
                    g,
                    [
                      b,
                      q
                    ],
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /smart-tv.+(samsung)/i
                  ],
                  [
                    b,
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /hbbtv.+maple;(\d+)/i
                  ],
                  [
                    [
                      g,
                      /^/,
                      "SmartTV"
                    ],
                    [
                      b,
                      D
                    ],
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i
                  ],
                  [
                    [
                      b,
                      "LG"
                    ],
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /(apple) ?tv/i
                  ],
                  [
                    b,
                    [
                      g,
                      N + " TV"
                    ],
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /crkey/i
                  ],
                  [
                    [
                      g,
                      E + "cast"
                    ],
                    [
                      b,
                      I
                    ],
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /droid.+aft(\w)( bui|\))/i
                  ],
                  [
                    g,
                    [
                      b,
                      O
                    ],
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /\(dtv[\);].+(aquos)/i,
                    /(aquos-tv[\w ]+)\)/i
                  ],
                  [
                    g,
                    [
                      b,
                      V
                    ],
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /(bravia[\w ]+)( bui|\))/i
                  ],
                  [
                    g,
                    [
                      b,
                      B
                    ],
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /(mitv-\w{5}) bui/i
                  ],
                  [
                    g,
                    [
                      b,
                      U
                    ],
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /Hbbtv.*(technisat) (.*);/i
                  ],
                  [
                    b,
                    g,
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i,
                    /hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i
                  ],
                  [
                    [
                      b,
                      X
                    ],
                    [
                      g,
                      X
                    ],
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i
                  ],
                  [
                    [
                      f,
                      x
                    ]
                  ],
                  [
                    /(ouya)/i,
                    /(nintendo) ([wids3utch]+)/i
                  ],
                  [
                    b,
                    g,
                    [
                      f,
                      w
                    ]
                  ],
                  [
                    /droid.+; (shield) bui/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Nvidia"
                    ],
                    [
                      f,
                      w
                    ]
                  ],
                  [
                    /(playstation [345portablevi]+)/i
                  ],
                  [
                    g,
                    [
                      b,
                      B
                    ],
                    [
                      f,
                      w
                    ]
                  ],
                  [
                    /\b(xbox(?: one)?(?!; xbox))[\); ]/i
                  ],
                  [
                    g,
                    [
                      b,
                      L
                    ],
                    [
                      f,
                      w
                    ]
                  ],
                  [
                    /((pebble))app/i
                  ],
                  [
                    b,
                    g,
                    [
                      f,
                      S
                    ]
                  ],
                  [
                    /(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i
                  ],
                  [
                    g,
                    [
                      b,
                      N
                    ],
                    [
                      f,
                      S
                    ]
                  ],
                  [
                    /droid.+; (glass) \d/i
                  ],
                  [
                    g,
                    [
                      b,
                      I
                    ],
                    [
                      f,
                      S
                    ]
                  ],
                  [
                    /droid.+; (wt63?0{2,3})\)/i
                  ],
                  [
                    g,
                    [
                      b,
                      q
                    ],
                    [
                      f,
                      S
                    ]
                  ],
                  [
                    /(quest( 2| pro)?)/i
                  ],
                  [
                    g,
                    [
                      b,
                      $
                    ],
                    [
                      f,
                      S
                    ]
                  ],
                  [
                    /(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i
                  ],
                  [
                    b,
                    [
                      f,
                      P
                    ]
                  ],
                  [
                    /(aeobc)\b/i
                  ],
                  [
                    g,
                    [
                      b,
                      O
                    ],
                    [
                      f,
                      P
                    ]
                  ],
                  [
                    /droid .+?; ([^;]+?)(?: bui|\) applew).+? mobile safari/i
                  ],
                  [
                    g,
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i
                  ],
                  [
                    g,
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i
                  ],
                  [
                    [
                      f,
                      _
                    ]
                  ],
                  [
                    /(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i
                  ],
                  [
                    [
                      f,
                      y
                    ]
                  ],
                  [
                    /(android[-\w\. ]{0,9});.+buil/i
                  ],
                  [
                    g,
                    [
                      b,
                      "Generic"
                    ]
                  ]
                ],
                engine: [
                  [
                    /windows.+ edge\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "EdgeHTML"
                    ]
                  ],
                  [
                    /webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "Blink"
                    ]
                  ],
                  [
                    /(presto)\/([\w\.]+)/i,
                    /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i,
                    /ekioh(flow)\/([\w\.]+)/i,
                    /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i,
                    /(icab)[\/ ]([23]\.[\d\.]+)/i,
                    /\b(libweb)/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /rv\:([\w\.]{1,9})\b.+(gecko)/i
                  ],
                  [
                    m,
                    h
                  ]
                ],
                os: [
                  [
                    /microsoft (windows) (vista|xp)/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /(windows) nt 6\.2; (arm)/i,
                    /(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i,
                    /(windows)[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i
                  ],
                  [
                    h,
                    [
                      m,
                      J,
                      Y
                    ]
                  ],
                  [
                    /(win(?=3|9|n)|win 9x )([nt\d\.]+)/i
                  ],
                  [
                    [
                      h,
                      "Windows"
                    ],
                    [
                      m,
                      J,
                      Y
                    ]
                  ],
                  [
                    /ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i,
                    /ios;fbsv\/([\d\.]+)/i,
                    /cfnetwork\/.+darwin/i
                  ],
                  [
                    [
                      m,
                      /_/g,
                      "."
                    ],
                    [
                      h,
                      "iOS"
                    ]
                  ],
                  [
                    /(mac os x) ?([\w\. ]*)/i,
                    /(macintosh|mac_powerpc\b)(?!.+haiku)/i
                  ],
                  [
                    [
                      h,
                      H
                    ],
                    [
                      m,
                      /_/g,
                      "."
                    ]
                  ],
                  [
                    /droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i
                  ],
                  [
                    m,
                    h
                  ],
                  [
                    /(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i,
                    /(blackberry)\w*\/([\w\.]*)/i,
                    /(tizen|kaios)[\/ ]([\w\.]+)/i,
                    /\((series40);/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /\(bb(10);/i
                  ],
                  [
                    m,
                    [
                      h,
                      T
                    ]
                  ],
                  [
                    /(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "Symbian"
                    ]
                  ],
                  [
                    /mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      M + " OS"
                    ]
                  ],
                  [
                    /web0s;.+rt(tv)/i,
                    /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "webOS"
                    ]
                  ],
                  [
                    /watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      "watchOS"
                    ]
                  ],
                  [
                    /crkey\/([\d\.]+)/i
                  ],
                  [
                    m,
                    [
                      h,
                      E + "cast"
                    ]
                  ],
                  [
                    /(cros) [\w]+(?:\)| ([\w\.]+)\b)/i
                  ],
                  [
                    [
                      h,
                      G
                    ],
                    m
                  ],
                  [
                    /panasonic;(viera)/i,
                    /(netrange)mmh/i,
                    /(nettv)\/(\d+\.[\w\.]+)/i,
                    /(nintendo|playstation) ([wids345portablevuch]+)/i,
                    /(xbox); +xbox ([^\);]+)/i,
                    /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i,
                    /(mint)[\/\(\) ]?(\w*)/i,
                    /(mageia|vectorlinux)[; ]/i,
                    /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i,
                    /(hurd|linux) ?([\w\.]*)/i,
                    /(gnu) ?([\w\.]*)/i,
                    /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i,
                    /(haiku) (\w+)/i
                  ],
                  [
                    h,
                    m
                  ],
                  [
                    /(sunos) ?([\w\.\d]*)/i
                  ],
                  [
                    [
                      h,
                      "Solaris"
                    ],
                    m
                  ],
                  [
                    /((?:open)?solaris)[-\/ ]?([\w\.]*)/i,
                    /(aix) ((\d)(?=\.|\)| )[\w\.])*/i,
                    /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i,
                    /(unix) ?([\w\.]*)/i
                  ],
                  [
                    h,
                    m
                  ]
                ]
              }, ee = function(e2, t2) {
                if (typeof e2 === d && (t2 = e2, e2 = s2), !(this instanceof ee)) return new ee(e2, t2).getResult();
                var r2 = typeof o2 !== u && o2.navigator ? o2.navigator : s2, n2 = e2 || (r2 && r2.userAgent ? r2.userAgent : ""), i3 = r2 && r2.userAgentData ? r2.userAgentData : s2, a3 = t2 ? F(Q, t2) : Q, w2 = r2 && r2.userAgent == n2;
                return this.getBrowser = function() {
                  var e3, t3 = {};
                  return t3[h] = s2, t3[m] = s2, Z.call(t3, n2, a3.browser), t3[p] = typeof (e3 = t3[m]) === c ? e3.replace(/[^\d\.]/g, "").split(".")[0] : s2, w2 && r2 && r2.brave && typeof r2.brave.isBrave == l && (t3[h] = "Brave"), t3;
                }, this.getCPU = function() {
                  var e3 = {};
                  return e3[v] = s2, Z.call(e3, n2, a3.cpu), e3;
                }, this.getDevice = function() {
                  var e3 = {};
                  return e3[b] = s2, e3[g] = s2, e3[f] = s2, Z.call(e3, n2, a3.device), w2 && !e3[f] && i3 && i3.mobile && (e3[f] = y), w2 && "Macintosh" == e3[g] && r2 && typeof r2.standalone !== u && r2.maxTouchPoints && r2.maxTouchPoints > 2 && (e3[g] = "iPad", e3[f] = _), e3;
                }, this.getEngine = function() {
                  var e3 = {};
                  return e3[h] = s2, e3[m] = s2, Z.call(e3, n2, a3.engine), e3;
                }, this.getOS = function() {
                  var e3 = {};
                  return e3[h] = s2, e3[m] = s2, Z.call(e3, n2, a3.os), w2 && !e3[h] && i3 && "Unknown" != i3.platform && (e3[h] = i3.platform.replace(/chrome os/i, G).replace(/macos/i, H)), e3;
                }, this.getResult = function() {
                  return {
                    ua: this.getUA(),
                    browser: this.getBrowser(),
                    engine: this.getEngine(),
                    os: this.getOS(),
                    device: this.getDevice(),
                    cpu: this.getCPU()
                  };
                }, this.getUA = function() {
                  return n2;
                }, this.setUA = function(e3) {
                  return n2 = typeof e3 === c && e3.length > 350 ? X(e3, 350) : e3, this;
                }, this.setUA(n2), this;
              };
              ee.VERSION = "1.0.35", ee.BROWSER = z([
                h,
                m,
                p
              ]), ee.CPU = z([
                v
              ]), ee.DEVICE = z([
                g,
                b,
                f,
                w,
                y,
                x,
                _,
                S,
                P
              ]), ee.ENGINE = ee.OS = z([
                h,
                m
              ]), typeof a2 !== u ? (i2.exports && (a2 = i2.exports = ee), a2.UAParser = ee) : r.amdO ? void 0 !== (n = function() {
                return ee;
              }.call(t, r, t, e)) && (e.exports = n) : typeof o2 !== u && (o2.UAParser = ee);
              var et = typeof o2 !== u && (o2.jQuery || o2.Zepto);
              if (et && !et.ua) {
                var er = new ee();
                et.ua = er.getResult(), et.ua.get = function() {
                  return er.getUA();
                }, et.ua.set = function(e2) {
                  er.setUA(e2);
                  var t2 = er.getResult();
                  for (var r2 in t2) et.ua[r2] = t2[r2];
                };
              }
            }("object" == typeof window ? window : this);
          }
        }, a = {};
        function o(e2) {
          var t2 = a[e2];
          if (void 0 !== t2) return t2.exports;
          var r2 = a[e2] = {
            exports: {}
          }, n2 = true;
          try {
            i[e2].call(r2.exports, r2, r2.exports, o), n2 = false;
          } finally {
            n2 && delete a[e2];
          }
          return r2.exports;
        }
        o.ab = "//";
        var s = o(226);
        e.exports = s;
      })();
    },
    387: (e) => {
      "use strict";
      e.exports = [
        "chrome 64",
        "edge 79",
        "firefox 67",
        "opera 51",
        "safari 12"
      ];
    },
    703: (e, t, r) => {
      "use strict";
      Object.defineProperty(t, "__esModule", {
        value: true
      }), function(e2, t2) {
        for (var r2 in t2) Object.defineProperty(e2, r2, {
          enumerable: true,
          get: t2[r2]
        });
      }(t, {
        getTestReqInfo: function() {
          return o;
        },
        withRequest: function() {
          return a;
        }
      });
      let n = new (r(67)).AsyncLocalStorage();
      function i(e2, t2) {
        let r2 = t2.header(e2, "next-test-proxy-port");
        if (r2) return {
          url: t2.url(e2),
          proxyPort: Number(r2),
          testData: t2.header(e2, "next-test-data") || ""
        };
      }
      function a(e2, t2, r2) {
        let a2 = i(e2, t2);
        return a2 ? n.run(a2, r2) : r2();
      }
      function o(e2, t2) {
        return n.getStore() || (e2 && t2 ? i(e2, t2) : void 0);
      }
    },
    407: (e, t, r) => {
      "use strict";
      var n = r(195).Buffer;
      Object.defineProperty(t, "__esModule", {
        value: true
      }), function(e2, t2) {
        for (var r2 in t2) Object.defineProperty(e2, r2, {
          enumerable: true,
          get: t2[r2]
        });
      }(t, {
        handleFetch: function() {
          return s;
        },
        interceptFetch: function() {
          return l;
        },
        reader: function() {
          return a;
        }
      });
      let i = r(703), a = {
        url: (e2) => e2.url,
        header: (e2, t2) => e2.headers.get(t2)
      };
      async function o(e2, t2) {
        let { url: r2, method: i2, headers: a2, body: o2, cache: s2, credentials: l2, integrity: u, mode: d, redirect: c, referrer: p, referrerPolicy: g } = t2;
        return {
          testData: e2,
          api: "fetch",
          request: {
            url: r2,
            method: i2,
            headers: [
              ...Array.from(a2),
              [
                "next-test-stack",
                function() {
                  let e3 = (Error().stack ?? "").split("\n");
                  for (let t3 = 1; t3 < e3.length; t3++) if (e3[t3].length > 0) {
                    e3 = e3.slice(t3);
                    break;
                  }
                  return (e3 = (e3 = (e3 = e3.filter((e4) => !e4.includes("/next/dist/"))).slice(0, 5)).map((e4) => e4.replace("webpack-internal:///(rsc)/", "").trim())).join("    ");
                }()
              ]
            ],
            body: o2 ? n.from(await t2.arrayBuffer()).toString("base64") : null,
            cache: s2,
            credentials: l2,
            integrity: u,
            mode: d,
            redirect: c,
            referrer: p,
            referrerPolicy: g
          }
        };
      }
      async function s(e2, t2) {
        let r2 = (0, i.getTestReqInfo)(t2, a);
        if (!r2) return e2(t2);
        let { testData: s2, proxyPort: l2 } = r2, u = await o(s2, t2), d = await e2(`http://localhost:${l2}`, {
          method: "POST",
          body: JSON.stringify(u),
          next: {
            internal: true
          }
        });
        if (!d.ok) throw Error(`Proxy request failed: ${d.status}`);
        let c = await d.json(), { api: p } = c;
        switch (p) {
          case "continue":
            return e2(t2);
          case "abort":
          case "unhandled":
            throw Error(`Proxy request aborted [${t2.method} ${t2.url}]`);
        }
        return function(e3) {
          let { status: t3, headers: r3, body: i2 } = e3.response;
          return new Response(i2 ? n.from(i2, "base64") : null, {
            status: t3,
            headers: new Headers(r3)
          });
        }(c);
      }
      function l(e2) {
        return r.g.fetch = function(t2, r2) {
          var n2;
          return (null == r2 ? void 0 : null == (n2 = r2.next) ? void 0 : n2.internal) ? e2(t2, r2) : s(e2, new Request(t2, r2));
        }, () => {
          r.g.fetch = e2;
        };
      }
    },
    311: (e, t, r) => {
      "use strict";
      Object.defineProperty(t, "__esModule", {
        value: true
      }), function(e2, t2) {
        for (var r2 in t2) Object.defineProperty(e2, r2, {
          enumerable: true,
          get: t2[r2]
        });
      }(t, {
        interceptTestApis: function() {
          return a;
        },
        wrapRequestHandler: function() {
          return o;
        }
      });
      let n = r(703), i = r(407);
      function a() {
        return (0, i.interceptFetch)(r.g.fetch);
      }
      function o(e2) {
        return (t2, r2) => (0, n.withRequest)(t2, i.reader, () => e2(t2, r2));
      }
    }
  },
  (e) => {
    var t = e(e.s = 656);
    (_ENTRIES = "undefined" == typeof _ENTRIES ? {} : _ENTRIES).middleware_middleware = t;
  }
]);
var middlewareEntryKey = Object.keys(_ENTRIES).find((entryKey) => entryKey.startsWith("middleware_middleware"));
var middleware_default = await _ENTRIES[middlewareEntryKey].default;

// .netlify/edge-functions/___netlify-edge-handler-middleware/___netlify-edge-handler-middleware.js
var netlify_edge_handler_middleware_default = (req, context) => handleMiddleware(req, context, middleware_default);
export {
  netlify_edge_handler_middleware_default as default
};
